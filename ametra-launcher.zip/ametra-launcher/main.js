const { app, BrowserWindow, ipcMain, shell, dialog, safeStorage } = require('electron');
const path = require('path');
const fs = require('fs');
const { Client, Authenticator } = require('minecraft-launcher-core');
const { Auth } = require('msmc');
const { execFile } = require('child_process');
const os = require('os');
const opt = require('./optimizer');

const ROOT = () => {
  const dir = path.join(app.getPath('appData'), '.ametra');
  const old = path.join(app.getPath('appData'), '.hovyclient'); // nombre anterior: se mueve para no perder instancias
  try { if (!fs.existsSync(dir) && fs.existsSync(old)) fs.renameSync(old, dir); } catch { /* en uso: se usa la carpeta nueva vacía */ }
  return dir;
};
const modsDir = (id) => {
  const d = path.join(ROOT(), 'instances', id, 'mods');
  fs.mkdirSync(d, { recursive: true });
  return d;
};
const UA = { 'User-Agent': 'ametra-launcher/1.0' };

let win;
let msAccount = null; // sesión de Microsoft (solo en memoria)

function createWindow() {
  win = new BrowserWindow({
    width: 1000, height: 620, frame: false, resizable: false, backgroundColor: '#050505',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true }
  });
  win.loadFile('index.html');
}
app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());

ipcMain.on('win:min', () => win.minimize());
ipcMain.on('win:close', () => win.close());
ipcMain.on('skin:open', () => shell.openExternal('https://www.minecraft.net/msaprofile/mygames/editskin'));

// ---------- Microsoft (premium) ----------
ipcMain.handle('login:ms', async (_e, silent) => {
  const file = path.join(app.getPath('userData'), 'ms-session.bin');
  const auth = new Auth('select_account');
  let xbox = null;
  try {
    if (fs.existsSync(file) && safeStorage.isEncryptionAvailable()) {
      xbox = await auth.refresh(safeStorage.decryptString(fs.readFileSync(file)));
    }
  } catch { xbox = null; }
  if (!xbox) {
    if (silent) throw new Error('Sin sesión guardada.');
    xbox = await auth.launch('electron');
  }
  const mc = await xbox.getMinecraft();
  if (safeStorage.isEncryptionAvailable()) fs.writeFileSync(file, safeStorage.encryptString(xbox.save()));
  msAccount = mc.mclc();
  const skins = mc.profile.skins || [];
  const sk = skins.find((s) => s.state === 'ACTIVE') || skins[0];
  let skin = null, slim = false;
  if (sk && sk.url) {
    try {
      skin = 'data:image/png;base64,' + Buffer.from(await (await fetch(sk.url)).arrayBuffer()).toString('base64');
      slim = /slim/i.test(sk.variant || '');
    } catch { skin = null; }
  }
  return { name: mc.profile.name, skin, slim };
});

// ---------- Versiones ----------
ipcMain.handle('versions:list', async () => {
  const r = await fetch('https://launchermeta.mojang.com/mc/game/version_manifest_v2.json', { headers: UA });
  const data = await r.json();
  return data.versions.filter((v) => v.type === 'release').map((v) => v.id);
});

// ---------- Mods ----------
ipcMain.handle('mods:add', async (_e, id) => {
  const r = await dialog.showOpenDialog(win, { filters: [{ name: 'Mods', extensions: ['jar'] }], properties: ['openFile', 'multiSelections'] });
  if (r.canceled) return 0;
  const dir = modsDir(id);
  r.filePaths.forEach((f) => fs.copyFileSync(f, path.join(dir, path.basename(f))));
  return r.filePaths.length;
});
ipcMain.handle('mods:open', (_e, id) => shell.openPath(modsDir(id)));

// ---------- Módulos del cliente (mods reales de Modrinth) ----------
const instDir = (id) => path.join(ROOT(), 'instances', id);
const regFile = (id) => path.join(instDir(id), 'ametra-mods.json');
const readReg = (id) => { try { return JSON.parse(fs.readFileSync(regFile(id), 'utf8')); } catch { return {}; } };

async function installMod(slug, version, dir, seen = new Set(), loader = 'fabric') {
  if (seen.has(slug)) return null;
  seen.add(slug);
  const url = `https://api.modrinth.com/v2/project/${slug}/version?game_versions=${encodeURIComponent(JSON.stringify([version]))}&loaders=${encodeURIComponent(JSON.stringify([loader]))}`;
  const vers = await (await fetch(url, { headers: UA })).json();
  if (!Array.isArray(vers) || !vers.length) throw new Error(`Este mod no tiene versión para Minecraft ${version}.`);
  const v = vers.find((x) => x.version_type === 'release') || vers[0]; // mejor una versión estable que una alpha
  for (const d of v.dependencies || []) {
    if (d.dependency_type === 'required' && d.project_id) {
      try { await installMod(d.project_id, version, dir, seen, loader); } catch { /* dependencia opcional o no disponible */ }
    }
  }
  const f = v.files.find((x) => x.primary) || v.files[0];
  const target = path.join(dir, f.filename);
  if (!fs.existsSync(target)) fs.writeFileSync(target, Buffer.from(await (await fetch(f.url, { headers: UA })).arrayBuffer()));
  return f.filename;
}

ipcMain.handle('client:mods', (_e, id) => Object.keys(readReg(id)));
ipcMain.handle('mod:status', () => fs.existsSync(path.join(__dirname, 'mod', 'ametra-client.jar')));
ipcMain.handle('client:toggle', async (_e, { id, version, slug, on }) => {
  const reg = readReg(id);
  const dir = modsDir(id);
  if (on) {
    reg[slug] = await installMod(slug, version, dir);
  } else if (reg[slug]) {
    try { fs.unlinkSync(path.join(dir, reg[slug])); } catch { /* ya no existe */ }
    delete reg[slug];
  }
  fs.writeFileSync(regFile(id), JSON.stringify(reg));
  return Object.keys(reg);
});
// El mod (Ametra Client) y el launcher comparten config/ametra.json: se mezcla, no se pisa.
const cfgFile = (id) => path.join(instDir(id), 'config', 'ametra.json');
const readCfg = (id) => { try { return JSON.parse(fs.readFileSync(cfgFile(id), 'utf8')); } catch { return {}; } };
ipcMain.handle('client:config', (_e, { id, config }) => {
  fs.mkdirSync(path.dirname(cfgFile(id)), { recursive: true });
  const cur = readCfg(id);
  const next = { ...cur, ...config };
  if (config.hud) next.hud = { ...(cur.hud || {}), ...config.hud };
  fs.writeFileSync(cfgFile(id), JSON.stringify(next, null, 2));
});
ipcMain.handle('client:readConfig', (_e, id) => readCfg(id));

// ---------- Fabric / Legacy Fabric ----------
const META = { fabric: 'https://meta.fabricmc.net/v2/versions/loader', 'legacy-fabric': 'https://meta.legacyfabric.net/v2/versions/loader' };
async function ensureLoader(version, kind = 'fabric') {
  const base = META[kind];
  const list = await (await fetch(`${base}/${version}`, { headers: UA })).json();
  if (!Array.isArray(list) || !list.length) throw new Error(`${kind === 'fabric' ? 'Fabric' : 'Legacy Fabric'} no soporta la versión ${version}.`);
  const loader = (list.find((l) => l.loader.stable) || list[0]).loader.version;
  const prof = await (await fetch(`${base}/${version}/${loader}/profile/json`, { headers: UA })).text();
  let id = `fabric-loader-${loader}-${version}`;
  try { id = JSON.parse(prof).id || id; } catch { /* se queda con el nombre calculado */ }
  const dir = path.join(ROOT(), 'versions', id);
  const file = path.join(dir, `${id}.json`);
  if (!fs.existsSync(file)) {
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(file, prof);
  }
  return id;
}
const ensureFabric = (version) => ensureLoader(version, 'fabric');
async function ensureFabricApi(version, dir) {
  if (fs.readdirSync(dir).some((f) => /^fabric-api/i.test(f))) return;
  const url = `https://api.modrinth.com/v2/project/fabric-api/version?game_versions=${encodeURIComponent(JSON.stringify([version]))}&loaders=${encodeURIComponent('["fabric"]')}`;
  const vers = await (await fetch(url, { headers: UA })).json();
  const best = Array.isArray(vers) && (vers.find((x) => x.version_type === 'release') || vers[0]);
  const files = best && best.files;
  const f = files && (files.find((x) => x.primary) || files[0]);
  if (!f) return;
  fs.writeFileSync(path.join(dir, f.filename), Buffer.from(await (await fetch(f.url, { headers: UA })).arrayBuffer()));
}

// ---------- Java automático ----------
const run = (cmd, args) => new Promise((res) => {
  try { execFile(cmd, args, { timeout: 15000, windowsHide: true }, (err, so, se) => res({ err, out: `${so || ''}${se || ''}` })); }
  catch (e) { res({ err: e, out: '' }); }
});
async function javaInfoOf(p) {
  const { out } = await run(p, ['-version']);
  const m = /version "(\d+)(?:\.(\d+))?(?:\.(\d+))?(?:_(\d+))?/.exec(out);
  if (!m) return { major: 0, update: 0 };
  if (m[1] === '1') return { major: Number(m[2]), update: Number(m[4] || 0) }; // 1.8.0_432 -> 8 update 432
  return { major: Number(m[1]), update: 0 };
}
// Qué Java necesita una versión de Minecraft (Mojang lo dice en el JSON de la versión; si no hay internet, se calcula).
async function javaMajor(version) {
  try {
    const man = await (await fetch('https://launchermeta.mojang.com/mc/game/version_manifest_v2.json', { headers: UA })).json();
    const v = man.versions.find((x) => x.id === version);
    if (v) {
      const j = await (await fetch(v.url, { headers: UA })).json();
      if (j.javaVersion && j.javaVersion.majorVersion) return j.javaVersion.majorVersion;
    }
  } catch { /* sin internet */ }
  const [, minor, patch] = (/^1\.(\d+)(?:\.(\d+))?/.exec(version) || []).map(Number);
  if (!minor) return 21;
  if (minor > 20 || (minor === 20 && (patch || 0) >= 5)) return 21;
  if (minor >= 17) return 17;
  return 8;
}
function subdirs(d) { try { return fs.readdirSync(d, { withFileTypes: true }).filter((e) => e.isDirectory()).map((e) => path.join(d, e.name)); } catch { return []; } }
function javaCandidates() {
  const exe = process.platform === 'win32' ? 'java.exe' : 'java';
  const out = ['java'];
  if (process.env.JAVA_HOME) out.push(path.join(process.env.JAVA_HOME, 'bin', exe));
  const roots = [];
  if (process.platform === 'win32') {
    for (const pf of [process.env['ProgramFiles'], process.env['ProgramFiles(x86)']].filter(Boolean)) {
      for (const v of ['Java', 'Eclipse Adoptium', 'Microsoft', 'Zulu', 'Amazon Corretto', 'BellSoft', 'Semeru', 'AdoptOpenJDK']) roots.push(path.join(pf, v));
    }
    // Java que trae el launcher oficial de Minecraft
    for (const r of subdirs(path.join(app.getPath('appData'), '.minecraft', 'runtime'))) {
      for (const p of subdirs(r)) for (const q of subdirs(p)) out.push(path.join(q, 'bin', exe));
    }
  } else if (process.platform === 'darwin') {
    for (const j of subdirs('/Library/Java/JavaVirtualMachines')) out.push(path.join(j, 'Contents', 'Home', 'bin', exe));
  } else {
    roots.push('/usr/lib/jvm');
  }
  for (const r of roots) for (const j of subdirs(r)) out.push(path.join(j, 'bin', exe));
  return out;
}
function findJavaBin(dir, depth = 0) {
  const exe = process.platform === 'win32' ? 'java.exe' : 'java';
  const direct = path.join(dir, 'bin', exe);
  if (fs.existsSync(direct)) return direct;
  if (depth > 4) return null;
  for (const s of subdirs(dir)) { const r = findJavaBin(s, depth + 1); if (r) return r; }
  return null;
}
async function downloadJava(major, send) {
  const osName = { win32: 'windows', darwin: 'mac', linux: 'linux' }[process.platform];
  const arch = process.arch === 'arm64' ? 'aarch64' : 'x64';
  if (!osName) throw new Error('Sistema no soportado para descargar Java.');
  const dest = path.join(ROOT(), 'runtime', `java-${major}`);
  const hit = fs.existsSync(dest) && findJavaBin(dest);
  if (hit) return hit;
  fs.mkdirSync(dest, { recursive: true });
  const url = `https://api.adoptium.net/v3/binary/latest/${major}/ga/${osName}/${arch}/jre/hotspot/normal/eclipse`;
  send('info', `Descargando Java ${major}…`);
  const r = await fetch(url, { headers: UA });
  if (!r.ok) throw new Error(`No se pudo descargar Java ${major} (HTTP ${r.status}). Instálalo a mano desde adoptium.net.`);
  const total = Number(r.headers.get('content-length')) || 0;
  const file = path.join(os.tmpdir(), `ametra-java-${major}${osName === 'windows' ? '.zip' : '.tar.gz'}`);
  const ws = fs.createWriteStream(file);
  let got = 0, last = 0;
  const reader = r.body.getReader();
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    ws.write(Buffer.from(value));
    got += value.length;
    if (total && Date.now() - last > 300) { last = Date.now(); send('info', `Descargando Java ${major}… ${Math.round((got / total) * 100)}%`); }
  }
  await new Promise((res) => ws.end(res));
  send('info', `Instalando Java ${major}…`);
  // tar viene con Windows 10+, macOS y Linux, y también abre .zip
  const t = await run('tar', [osName === 'windows' ? '-xf' : '-xzf', file, '-C', dest]);
  try { fs.unlinkSync(file); } catch { /* ya no está */ }
  const bin = findJavaBin(dest);
  if (!bin) throw new Error(`No se pudo instalar Java ${major}. ${t.err ? t.err.message : ''}`);
  return bin;
}
// Devuelve la ruta del Java correcto: el tuyo si sirve, uno instalado, o uno descargado.
// minUpdate: para Java 8, rechaza builds viejos (antes de 8u312 fallan TLS con Mojang y tienen bugs de GC).
async function resolveJava(major, userPath, send, minUpdate = 0, allowNewer = true) {
  send('info', `Buscando Java ${major}…`);
  const seen = new Set();
  const found = [];
  const list = [userPath, ...javaCandidates()].filter(Boolean);
  for (const p of list) {
    if (seen.has(p)) continue;
    seen.add(p);
    if (p !== 'java' && !fs.existsSync(p)) continue;
    const j = await javaInfoOf(p);
    if (j.major) found.push({ p, m: j.major, u: j.update });
  }
  const exact = found.find((f) => f.m === major && (!minUpdate || f.u >= minUpdate));
  if (exact) return exact.p;
  const newer = allowNewer && major > 8 && found.find((f) => f.m > major && f.m <= major + 4);
  if (newer) return newer.p;
  if (minUpdate && found.some((f) => f.m === major)) send('info', `Tu Java ${major} es antiguo: descargando el más reciente…`);
  return downloadJava(major, send);
}

// Instala el mod Ametra Client (menú con Shift derecho). El .jar va en mod/ametra-client.jar (ver README).
function ensureAmetraMod(version, dir, enabled, send) {
  for (const f of fs.readdirSync(dir)) {
    if (/^ametra-client.*\.jar$/i.test(f)) { try { fs.unlinkSync(path.join(dir, f)); } catch { /* en uso */ } }
  }
  if (!enabled) return;
  if (version !== '1.21.1') { send('warn', 'El menú de Ametra (Shift derecho) solo existe para Minecraft 1.21.1. Crea una instancia 1.21.1.'); return; }
  const src = path.join(__dirname, 'mod', 'ametra-client.jar');
  if (!fs.existsSync(src)) { send('warn', 'No se instaló el menú: falta el archivo mod/ametra-client.jar. Hay que compilar el mod (mira el README: GitHub Actions).'); return; }
  fs.copyFileSync(src, path.join(dir, 'ametra-client.jar'));
  send('warn', '');
}

// ---------- Pack de optimización ----------
// Registro propio (ametra-opt.json) para no mezclarlo con los mods que el usuario activa a mano.
const optFile = (id) => path.join(instDir(id), 'ametra-opt.json');
const readOpt = (id) => { try { return JSON.parse(fs.readFileSync(optFile(id), 'utf8')); } catch { return { files: {} }; } };

async function discoverLegacy(version) {
  // Mods de rendimiento reales para Legacy Fabric en esta versión exacta (los más descargados, que funcionen en cliente).
  const facets = JSON.stringify([['project_type:mod'], ['categories:legacy-fabric'], ['categories:optimization'], [`versions:${version}`]]);
  const url = `https://api.modrinth.com/v2/search?limit=12&index=downloads&facets=${encodeURIComponent(facets)}`;
  const r = await (await fetch(url, { headers: UA })).json();
  return (r.hits || []).filter((h) => h.client_side !== 'unsupported').slice(0, opt.LEGACY_DISCOVER_MAX).map((h) => ({ slug: h.slug, name: h.title }));
}

// Instala (o repara) el pack en la instancia. Nunca lanza: devuelve qué se instaló y qué se saltó.
async function installPack(id, version, requiredJava, send) {
  const p = opt.plan(version, requiredJava);
  const dir = modsDir(id);
  const reg = readOpt(id);
  const out = { installed: [], skipped: [], failed: [], loader: p.loader };
  if (!p.loader) return out;
  reg.mc = version; reg.loader = p.loader; reg.files = reg.files || {};
  let items = p.mods.slice();
  try { if (p.discover) items = items.concat(await discoverLegacy(version)); } catch { /* sin internet: solo lo básico */ }
  for (const m of items) {
    const have = reg.files[m.slug];
    if (have && fs.existsSync(path.join(dir, have))) { out.installed.push(m.name); continue; }
    try {
      send('info', `Pack de optimización: ${m.name}…`);
      const f = await installMod(m.slug, version, dir, new Set(), p.loader);
      if (f) { reg.files[m.slug] = f; out.installed.push(m.name); }
    } catch { out.skipped.push(m.name); } // no hay build para esta versión: normal, se salta
  }
  fs.mkdirSync(instDir(id), { recursive: true });
  fs.writeFileSync(optFile(id), JSON.stringify(reg, null, 2));
  return out;
}
function removePack(id) {
  const reg = readOpt(id);
  for (const f of Object.values(reg.files || {})) { try { fs.unlinkSync(path.join(modsDir(id), f)); } catch { /* ya no está */ } }
  try { fs.unlinkSync(optFile(id)); } catch { /* no había */ }
}
// Ajustes de vídeo ligeros SOLO la primera vez (si el usuario ya tiene options.txt no se toca).
function seedVideoOptions(id, version) {
  const v = opt.videoOptions(version);
  const f = path.join(instDir(id), 'options.txt');
  if (!v || fs.existsSync(f)) return false;
  fs.mkdirSync(instDir(id), { recursive: true });
  fs.writeFileSync(f, Object.entries(v).map(([k, val]) => `${k}:${val}`).join('\n') + '\n');
  return true;
}

ipcMain.handle('opt:plan', async (_e, version) => {
  const p = opt.plan(version, await javaMajor(version));
  return { era: p.era, loader: p.loader, java: p.java, mods: p.mods.map((m) => ({ name: m.name, why: m.why })), discover: p.discover, video: !!p.video };
});
ipcMain.handle('opt:install', async (event, { id, version }) => {
  const send = (ch, d) => event.sender.send(ch, d);
  const major = await javaMajor(version);
  const p = opt.plan(version, major);
  if (p.loader) await ensureLoader(version, p.loader);
  if (p.loader === 'fabric') await ensureFabricApi(version, modsDir(id));
  return installPack(id, version, major, send);
});

// ---------- Jugar ----------
ipcMain.handle('play', async (event, { id, name, version, ram, java, mode, fabric, ametra, optimize, modernJava }) => {
  const send = (ch, d) => event.sender.send(ch, d);
  try {
    let authorization;
    if (mode === 'ms') {
      if (!msAccount) throw new Error('Inicia sesión con Microsoft en Cuenta.');
      authorization = msAccount;
    } else {
      authorization = Authenticator.getAuth(name);
    }

    const mods = modsDir(id);
    const ver = { number: version, type: 'release' };
    const required = await javaMajor(version);
    const plan = opt.plan(version, required);
    const useOpt = optimize !== false;
    const wantAmetra = ametra !== false && version === '1.21.1';

    // 1) Loader: el pack lo necesita en cualquier versión que tenga uno (Fabric o Legacy Fabric).
    const kind = (fabric || wantAmetra || useOpt) ? plan.loader : null;
    if (kind) {
      send('info', kind === 'fabric' ? 'Preparando Fabric…' : 'Preparando Legacy Fabric…');
      ver.custom = await ensureLoader(version, kind);
      if (kind === 'fabric') await ensureFabricApi(version, mods);
      if (fabric || wantAmetra) ensureAmetraMod(version, mods, ametra !== false, send);
      if (useOpt) {
        try {
          const r = await installPack(id, version, required, send);
          const n = r.installed.length;
          send('warn', n ? '' : 'No se pudo instalar el pack de optimización (¿sin internet?). Se juega igual.');
        } catch { send('warn', 'No se pudo instalar el pack de optimización. Se juega igual.'); }
      }
    } else {
      send('warn', '');
    }
    if (!useOpt && fs.existsSync(optFile(id))) removePack(id); // lo apagaste: se quitan SOLO los mods del pack
    if (useOpt) seedVideoOptions(id, version);

    // 2) Java: sube a uno moderno cuando es seguro; en versiones viejas, al Java 8 más nuevo.
    const major = modernJava === false ? required : plan.java.target;
    const minUpdate = major === 8 ? opt.MIN_JAVA8_UPDATE : 0;
    const javaPath = await resolveJava(major, java, send, minUpdate, major === required);
    send('info', `Usando Java ${major}${major > required ? ` (subido desde ${required})` : ''}…`);

    const launcher = new Client();
    let tail = '', started = false;
    launcher.on('progress', (p) => send('progress', { type: p.type, percent: Math.round((p.task / p.total) * 100) }));
    launcher.on('debug', (m) => console.log('[debug]', m));
    launcher.on('data', (d) => {
      tail = (tail + String(d)).slice(-6000);
      if (!started) { started = true; send('started'); }
    });
    launcher.on('close', (code) => {
      if (code !== 0) {
        if (/UnsupportedClassVersionError|class file version|requires Java/i.test(tail)) send('hint', `Java incorrecto: esta versión necesita Java ${required}. Borra la ruta de Java en Ajustes para que Ametra use el correcto.`);
        else if (major > required && /InaccessibleObjectException|IllegalAccessError|NoClassDefFoundError|Unsupported class file|Unable to make .* accessible/i.test(tail)) send('hint', `Falló con Java ${major} (subido desde ${required}). Desactiva "Java moderno" en Ajustes y vuelve a probar.`);
        else if (/OutOfMemoryError|Could not reserve enough space/i.test(tail)) send('hint', 'Poca memoria: baja o sube la RAM en Ajustes según tu PC.');
        else if (/Incompatible mod set|Mod resolution|requires .* of (minecraft|fabric)/i.test(tail)) send('hint', 'Un mod no es compatible con esta versión de Minecraft. Quita mods en la pestaña Cliente.');
      }
      send('closed', code);
    });

    launcher.launch({
      authorization,
      root: ROOT(),
      version: ver,
      memory: { max: `${ram}G`, min: '1G' },
      javaPath,
      customArgs: opt.jvmArgs(major, ram),
      overrides: { gameDirectory: path.join(ROOT(), 'instances', id) }
    });
  } catch (e) {
    send('error', e.message);
  }
});
