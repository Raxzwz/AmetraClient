# Ametra Launcher + Ametra Client

## 1) Correr el launcher (VS Code)
1. Instala Node.js (https://nodejs.org). Java no hace falta: el launcher detecta qué Java necesita cada versión (21 para 1.21.x, 17 para 1.18–1.20.4, 8 para 1.16 y anteriores), usa uno que ya tengas o descarga el correcto solo.
2. En esta carpeta, en la terminal:
   ```
   npm install
   npm start
   ```
3. Instalador .exe: `npm run build` (sale en `dist/`).

## 1b) Pack de optimización (todas las versiones)
Se activa solo al pulsar **Jugar** (Ajustes → "Pack de optimización automático") o a mano con **Cliente → Pack de optimización → Instalar ahora**.

| Versión de Minecraft | Loader | Qué se instala | Java |
|---|---|---|---|
| 1.20.5 en adelante (incluida la numeración 26.x) | Fabric | Sodium, Lithium, FerriteCore, ModernFix, Entity Culling, ImmediatelyFast, More Culling, Krypton, Dynamic FPS | lo que pida Mojang (21, 25…) |
| 1.18 – 1.20.4 | Fabric | lo mismo (+ Starlight hasta 1.20.1) | **sube de 17 a 21** |
| 1.17 | Fabric | Sodium, Lithium, Starlight, FerriteCore, ModernFix… | **sube de 16 a 17** |
| 1.14 – 1.16.5 | Fabric | Lithium + Phosphor + LazyDFU (1.14–1.15); desde 1.16.x también Sodium, Starlight, FerriteCore, ModernFix, Entity Culling, Krypton, Dynamic FPS | **sube de 8 a 17** |
| 1.3.2 – 1.13.2 | Legacy Fabric | Legacy Fabric API + los mods de la categoría "optimization" más descargados que existan para esa versión exacta | Java 8 (el más nuevo; mínimo 8u312) |
| 1.0 – 1.3.1 | ninguno | solo flags de JVM y ajustes de vídeo | Java 8 (mínimo 8u312) |

Notas importantes:
- **Por qué las versiones ≤ 1.13.2 no suben de Java 8:** su arranque (LaunchWrapper/LWJGL 2) se rompe con Java 9 o más nuevo. Lo que sí se hace es exigir un Java 8 reciente y descargar uno si el del PC es viejo.
- Cada mod se pide a Modrinth para la versión exacta; si no existe build, se salta sin error. Siempre se prefiere la versión estable (release).
- Si algo falla con el Java subido, desmarca **Java moderno** en Ajustes.
- Si apagas el pack, al jugar se quitan solo los mods que el pack instaló (los tuyos no se tocan). Registro en `instances/<id>/ametra-opt.json`.
- En instancias ≤ 1.12.2 sin `options.txt` se crea uno con ajustes de vídeo ligeros (distancia 8, sin vsync, gráficos rápidos). Si ya existe, no se toca.

## 2) El menú dentro del juego (Ametra Client)
Es un mod de Fabric que está en `ametra-mod/` (solo **Minecraft 1.21.1** por ahora).

**Shift derecho** dentro de un mundo o servidor abre el menú (la tecla se cambia en Controles → "Ametra Client").

- **Módulos** (estilo Feather): rejilla de tarjetas con buscador, categorías (Info, Combate, Visual), favoritos ★ y un interruptor por tarjeta. Los tres puntos (o clic en la tarjeta) abren el panel de ajustes: color, chroma, escala, fondo, sombra, mover y reiniciar posición.
- **14 módulos**: Logo, FPS, CPS, Teclas, Ping, Coordenadas, Reloj, Velocidad, Dirección, Memoria, Servidor, Armadura, **Zoom** (mantén C) y **Fullbright**.
- **Tema**: selector de color completo para el acento, animaciones, bienvenida y efectos del menú principal.
- **Instalados**: lista de todos los mods de la instancia.
- **Mover HUD**: arrastra cada módulo, rueda para el tamaño, clic derecho para reiniciar.

Animaciones: apertura/cierre del menú, partículas, logo con pulso, tarjeta de bienvenida al entrar a un mundo o servidor, módulos que se deslizan al activarse, teclas que se iluminan, logo animado en el menú principal de Minecraft.

### Opción rápida en Windows: compilar-mod.bat
Haz doble clic en `compilar-mod.bat`. Descarga JDK 21 y Gradle solos (dentro de `.build-tools`), compila el mod y crea `mod/ametra-client.jar`. La primera vez tarda varios minutos.

### Sacar la v1.0.0 sin instalar nada (GitHub Actions)
1. Sube esta carpeta a un repositorio de GitHub.
2. Pestaña **Actions → Release → Run workflow**. Compila el mod y el instalador `.exe` en la nube y los deja como descargas.
3. Para publicarlo como release: `git tag v1.0.0 && git push --tags`.

### Compilar el mod a mano (alternativa)
Necesitas **Java 21** y **Gradle**. La forma más fácil y segura:
1. Entra a https://fabricmc.net/develop/template , elige Minecraft **1.21.1**, nombre de mod `ametra`, y **desmarca** "split client and common sources". Descarga y descomprime.
2. Copia mi carpeta `ametra-mod/src` encima de la `src` de esa plantilla (reemplaza todo).
3. En esa carpeta ejecuta `gradlew build` (Windows: `gradlew.bat build`).
4. Copia `build/libs/ametra-client-1.0.0.jar` (el que NO termina en `-sources`) a `mod/ametra-client.jar` aquí en el launcher.

(La carpeta `ametra-mod` también trae `build.gradle` y `gradle.properties` de referencia; si tienes Gradle instalado puedes ejecutar `gradle wrapper` dentro y luego `gradlew build`.)

### Cómo se conectan
- Al jugar con Fabric, el launcher copia `mod/ametra-client.jar` a la carpeta `mods` de la instancia (se puede desactivar en Ajustes) e instala Fabric API.
- Ambos comparten `instances/<id>/config/ametra.json`: lo que cambies en el juego (módulos, color) se ve en la pestaña Cliente del launcher y viceversa.

## Qué sigue
- Capas (capes) visibles en el juego: necesitan un mixin al render del jugador.
- Otras versiones de Minecraft: el mod depende de los nombres internos de cada versión, hay que portarlo.
