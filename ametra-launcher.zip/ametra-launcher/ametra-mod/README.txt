Código fuente del mod Ametra Client (Fabric, Minecraft 1.21.1).
Mira el README de la carpeta de arriba para compilarlo.
Fuentes: src/main/java/com/ametra  ·  Recursos: src/main/resources
