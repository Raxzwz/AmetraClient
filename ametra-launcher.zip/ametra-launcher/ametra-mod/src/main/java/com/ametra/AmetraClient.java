package com.ametra;

import org.lwjgl.glfw.GLFW;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

public class AmetraClient implements ClientModInitializer {
    /** Tecla del menú (Shift derecho por defecto; se cambia en Controles). */
    public static KeyBinding MENU_KEY;

    @Override
    public void onInitializeClient() {
        AmetraConfig.load();

        MENU_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.ametra.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.ametra"));

        Features.ZOOM_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.ametra.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "category.ametra"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            Features.tick(client);
            while (MENU_KEY.wasPressed()) {
                if (client.currentScreen == null && client.player != null) {
                    client.setScreen(new AmetraScreen(null));
                }
            }
        });

        HudRenderCallback.EVENT.register(Hud::render);
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> Welcome.start());
        Fx.register();
    }
}
