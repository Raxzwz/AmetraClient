package com.ametra;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashSet;
import java.util.Set;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.fabricmc.loader.api.FabricLoader;

/**
 * Configuración en config/ametra.json. El launcher escribe en el mismo archivo
 * (profile, cape, hud, accent), así que al guardar se relee el archivo y solo se tocan nuestras claves.
 */
public final class AmetraConfig {
    private AmetraConfig() {}

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("ametra.json");

    public static int accent = 0x8FD6A8;
    public static boolean animations = true, welcome = true, titleFx = true;
    public static final Set<String> favorites = new LinkedHashSet<>();

    private static JsonObject readFile() {
        try {
            if (Files.exists(FILE)) {
                JsonElement e = JsonParser.parseString(Files.readString(FILE));
                if (e.isJsonObject()) return e.getAsJsonObject();
            }
        } catch (Exception ignored) { /* archivo corrupto: se ignora */ }
        return new JsonObject();
    }

    private static JsonObject obj(JsonObject o, String k) {
        return o.has(k) && o.get(k).isJsonObject() ? o.getAsJsonObject(k) : new JsonObject();
    }

    private static boolean bool(JsonObject o, String k, boolean d) {
        try { return o.has(k) ? o.get(k).getAsBoolean() : d; } catch (Exception e) { return d; }
    }

    private static int num(JsonObject o, String k, int d) {
        try { return o.has(k) ? o.get(k).getAsInt() : d; } catch (Exception e) { return d; }
    }

    private static float fnum(JsonObject o, String k, float d) {
        try { return o.has(k) ? o.get(k).getAsFloat() : d; } catch (Exception e) { return d; }
    }

    private static String str(JsonObject o, String k) {
        try { return o.has(k) ? o.get(k).getAsString() : null; } catch (Exception e) { return null; }
    }

    public static void load() {
        JsonObject raw = readFile();
        accent = Colors.parse(str(raw, "accent"), 0x8FD6A8);
        animations = bool(raw, "animations", true);
        welcome = bool(raw, "welcome", true);
        titleFx = bool(raw, "titleFx", true);
        favorites.clear();
        if (raw.has("favorites") && raw.get("favorites").isJsonArray()) {
            for (JsonElement e : raw.getAsJsonArray("favorites")) {
                try { favorites.add(e.getAsString()); } catch (Exception ignored) { /* valor raro */ }
            }
        }
        JsonObject hud = obj(raw, "hud"), mods = obj(raw, "modules");
        for (HudModule m : Hud.MODULES) {
            ModuleCfg c = m.cfg;
            JsonObject o = obj(mods, m.id);
            c.enabled = bool(hud, m.id, m.defEnabled);
            c.x = num(o, "x", m.defX);
            c.y = num(o, "y", m.defY);
            c.scale = Math.max(0.5f, Math.min(2f, fnum(o, "scale", 1f)));
            c.color = Colors.parse(str(o, "color"), 0xFFFFFF);
            c.bg = bool(o, "bg", true);
            c.shadow = bool(o, "shadow", true);
            c.chroma = bool(o, "chroma", false);
            c.value = m.hasValue() ? Math.max(m.vMin, Math.min(m.vMax, fnum(o, "value", m.vDef))) : 0f;
            m.vis = c.enabled ? 1f : 0f;
        }
    }

    public static void save() {
        JsonObject raw = readFile();
        raw.addProperty("accent", Colors.hex(accent));
        raw.addProperty("animations", animations);
        raw.addProperty("welcome", welcome);
        raw.addProperty("titleFx", titleFx);
        JsonObject hud = new JsonObject(), mods = new JsonObject();
        for (HudModule m : Hud.MODULES) {
            ModuleCfg c = m.cfg;
            hud.addProperty(m.id, c.enabled);
            JsonObject o = new JsonObject();
            o.addProperty("x", c.x);
            o.addProperty("y", c.y);
            o.addProperty("scale", Math.round(c.scale * 100f) / 100f);
            o.addProperty("color", Colors.hex(c.color));
            o.addProperty("bg", c.bg);
            o.addProperty("shadow", c.shadow);
            o.addProperty("chroma", c.chroma);
            if (m.hasValue()) o.addProperty("value", Math.round(c.value * 100f) / 100f);
            mods.add(m.id, o);
        }
        JsonArray fav = new JsonArray();
        for (String f : favorites) fav.add(f);
        raw.add("favorites", fav);
        raw.add("hud", hud);
        raw.add("modules", mods);
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(raw));
        } catch (IOException ignored) { /* sin permisos: no pasa nada */ }
    }
}
