package com.ametra;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.List;
import java.util.Locale;

import org.lwjgl.glfw.GLFW;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.item.ItemStack;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.math.MatrixStack;

/** Lista de módulos del HUD y su render. */
public final class Hud {
    private Hud() {}

    // ---------- Contador de clics ----------
    static final class Cps {
        static final ArrayDeque<Long> L = new ArrayDeque<>(), R = new ArrayDeque<>();
        static boolean lp, rp, leftDown, rightDown;

        static void poll(MinecraftClient mc) {
            long win = mc.getWindow().getHandle();
            boolean l = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
            boolean r = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
            long now = System.currentTimeMillis();
            boolean free = mc.currentScreen == null;
            if (free && l && !lp) L.addLast(now);
            if (free && r && !rp) R.addLast(now);
            lp = l;
            rp = r;
            leftDown = l && free;
            rightDown = r && free;
            while (!L.isEmpty() && now - L.peekFirst() > 1000) L.pollFirst();
            while (!R.isEmpty() && now - R.peekFirst() > 1000) R.pollFirst();
        }
    }

    // ---------- Módulo de texto: [barra] ETIQUETA valor ----------
    abstract static class TextModule extends HudModule {
        TextModule(String id, String name, String desc, String cat, int x, int y, boolean en) {
            super(id, name, desc, cat, x, y, en);
        }

        abstract String label();

        abstract String value(MinecraftClient mc);

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc, float alpha, int color) {
            String l = label(), v = value(mc);
            int lw = Gfx.width(l), vw = Gfx.width(v);
            w = 2 + 5 + lw + 5 + vw + 5;
            h = 15;
            if (cfg.bg) Gfx.rbox(ctx, 0, 0, w, h, 0x000000, 0.48f * alpha);
            Gfx.rect(ctx, 0, 1, 2, h - 2, cfg.chroma ? color : AmetraConfig.accent, alpha);
            Gfx.text(ctx, l, 7, 3, 0xA6A6B8, alpha, cfg.shadow);
            Gfx.text(ctx, v, 7 + lw + 5, 3, color, alpha, cfg.shadow);
        }
    }

    // ---------- Logo ----------
    static final class LogoModule extends HudModule {
        LogoModule() {
            super("logo", "Logo", "Logo de Ametra en pantalla.", "Visual", 6, 6, true);
        }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc, float alpha, int color) {
            int tw = Gfx.width("AMETRA") + 1;
            w = 4 + 16 + 5 + tw + 5;
            h = 22;
            if (cfg.bg) Gfx.rbox(ctx, 0, 0, w, h, 0x000000, 0.48f * alpha);
            float bob = (float) Math.sin(System.currentTimeMillis() / 600.0) * 0.8f;
            Gfx.logo(ctx, 4, 3 + bob, 16, alpha);
            Gfx.bold(ctx, "AMETRA", 25, 7, cfg.chroma ? color : AmetraConfig.accent, alpha, cfg.shadow);
        }
    }

    // ---------- Teclas (WASD, ratón, espacio) ----------
    static final class KeysModule extends HudModule {
        final float[] press = new float[8];

        KeysModule() {
            super("keys", "Teclas", "WASD, espacio y clics animados.", "Combate", 6, 124, true);
            w = 58;
            h = 72;
        }

        private void key(DrawContext ctx, int i, String label, int x, int y, int kw, int kh, boolean down, float alpha, int color) {
            press[i] += ((down ? 1f : 0f) - press[i]) * 0.3f;
            float p = press[i];
            float bgA = (cfg.bg ? 0.48f : 0.12f) * (1 - p) + 0.9f * p;
            Gfx.rbox(ctx, x, y, kw, kh, Colors.lerp(0x000000, color, p), bgA * alpha);
            int tc = Colors.lerp(0xE6E6F0, 0x0A0A12, p);
            if (!label.isEmpty()) {
                Gfx.text(ctx, label, x + (kw - Gfx.width(label)) / 2f, y + (kh - 8) / 2f, tc, alpha, false);
            } else {
                Gfx.rect(ctx, x + 8, y + kh / 2f - 0.5f, kw - 16, 1, tc, alpha);
            }
        }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc, float alpha, int color) {
            w = 58;
            h = 72;
            KeyBinding f = mc.options.forwardKey, l = mc.options.leftKey, b = mc.options.backKey, r = mc.options.rightKey;
            key(ctx, 0, "W", 20, 0, 18, 18, f.isPressed(), alpha, color);
            key(ctx, 1, "A", 0, 20, 18, 18, l.isPressed(), alpha, color);
            key(ctx, 2, "S", 20, 20, 18, 18, b.isPressed(), alpha, color);
            key(ctx, 3, "D", 40, 20, 18, 18, r.isPressed(), alpha, color);
            key(ctx, 4, "LMB", 0, 40, 28, 18, Cps.leftDown, alpha, color);
            key(ctx, 5, "RMB", 30, 40, 28, 18, Cps.rightDown, alpha, color);
            key(ctx, 6, "", 0, 60, 58, 12, mc.options.jumpKey.isPressed(), alpha, color);
        }
    }

    // ---------- Armadura y objeto en mano ----------
    static final class ArmorModule extends HudModule {
        ArmorModule() {
            super("armor", "Armadura", "Casco, peto, pantalón, botas y mano.", "Combate", 96, 124, false);
        }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc, float alpha, int color) {
            ItemStack[] st = new ItemStack[5];
            for (int i = 0; i < 4; i++) st[i] = mc.player.getInventory().getArmorStack(3 - i);
            st[4] = mc.player.getMainHandStack();
            int rows = 0, tw = 0;
            for (ItemStack it : st) {
                if (it.isEmpty()) continue;
                rows++;
                tw = Math.max(tw, Gfx.width(label(it)));
            }
            if (rows == 0) {
                w = 74;
                h = 15;
                if (cfg.bg) Gfx.rbox(ctx, 0, 0, w, h, 0x000000, 0.48f * alpha);
                Gfx.rect(ctx, 0, 1, 2, h - 2, AmetraConfig.accent, alpha);
                Gfx.text(ctx, "Sin armadura", 7, 3, 0xA6A6B8, alpha, cfg.shadow);
                return;
            }
            w = 4 + 16 + 4 + tw + 5;
            h = rows * 18 + 2;
            if (cfg.bg) Gfx.rbox(ctx, 0, 0, w, h, 0x000000, 0.48f * alpha);
            int y = 2;
            for (ItemStack it : st) {
                if (it.isEmpty()) continue;
                if (alpha > 0.6f) ctx.drawItem(it, 4, y);
                Gfx.text(ctx, label(it), 24, y + 4, color, alpha, cfg.shadow);
                y += 18;
            }
        }

        private static String label(ItemStack it) {
            if (it.getMaxDamage() > 0) return String.valueOf(it.getMaxDamage() - it.getDamage());
            return "";
        }
    }

    /** Función sin dibujo (zoom, fullbright): solo interruptor y ajustes. */
    static final class Feature extends HudModule {
        Feature(String id, String name, String desc, String cat, boolean en) {
            super(id, name, desc, cat, 0, 0, en);
            hud = false;
        }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc, float alpha, int color) { }
    }

    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");
    private static final String[] DIRS = {"N", "NE", "E", "SE", "S", "SO", "O", "NO"};

    public static final List<HudModule> MODULES = List.of(
        new LogoModule(),
        new TextModule("fps", "FPS", "Fotogramas por segundo.", "Info", 6, 32, true) {
            String label() { return "FPS"; }
            String value(MinecraftClient mc) { return String.valueOf(mc.getCurrentFps()); }
        },
        new TextModule("cps", "CPS", "Clics por segundo (izq. | der.).", "Combate", 6, 50, true) {
            String label() { return "CPS"; }
            String value(MinecraftClient mc) { return Cps.L.size() + " | " + Cps.R.size(); }
        },
        new KeysModule(),
        new TextModule("ping", "Ping", "Latencia con el servidor.", "Info", 6, 68, false) {
            String label() { return "PING"; }
            String value(MinecraftClient mc) {
                if (mc.isInSingleplayer()) return "local";
                ClientPlayNetworkHandler nh = mc.getNetworkHandler();
                PlayerListEntry e = (nh == null || mc.player == null) ? null : nh.getPlayerListEntry(mc.player.getUuid());
                return e == null ? "-" : e.getLatency() + " ms";
            }
        },
        new TextModule("coords", "Coordenadas", "Tu posición X Y Z.", "Info", 6, 86, false) {
            String label() { return "XYZ"; }
            String value(MinecraftClient mc) {
                if (mc.player == null) return "0 0 0";
                return (int) Math.floor(mc.player.getX()) + " " + (int) Math.floor(mc.player.getY()) + " " + (int) Math.floor(mc.player.getZ());
            }
        },
        new TextModule("clock", "Reloj", "La hora de tu equipo.", "Info", 6, 104, false) {
            String label() { return "HORA"; }
            String value(MinecraftClient mc) { return LocalTime.now().format(CLOCK); }
        },
        new TextModule("speed", "Velocidad", "Bloques por segundo.", "Info", 96, 32, false) {
            String label() { return "VEL"; }
            String value(MinecraftClient mc) {
                if (mc.player == null) return "0.0 b/s";
                double vx = mc.player.getVelocity().x, vz = mc.player.getVelocity().z;
                return String.format(Locale.ROOT, "%.1f b/s", Math.sqrt(vx * vx + vz * vz) * 20.0);
            }
        },
        new TextModule("dir", "Dirección", "Brújula: hacia dónde miras.", "Info", 96, 50, false) {
            String label() { return "DIR"; }
            String value(MinecraftClient mc) {
                if (mc.player == null) return "N";
                float yaw = ((mc.player.getYaw() % 360f) + 360f) % 360f;
                int idx = Math.round(((yaw + 180f) % 360f) / 45f) % 8;
                return DIRS[idx] + " " + Math.round(yaw);
            }
        },
        new TextModule("ram", "Memoria", "RAM que usa el juego.", "Info", 96, 68, false) {
            String label() { return "RAM"; }
            String value(MinecraftClient mc) {
                Runtime rt = Runtime.getRuntime();
                long used = (rt.totalMemory() - rt.freeMemory()) / 1048576L, max = rt.maxMemory() / 1048576L;
                return used + "/" + max + " MB";
            }
        },
        new TextModule("server", "Servidor", "La IP del servidor actual.", "Info", 96, 86, false) {
            String label() { return "IP"; }
            String value(MinecraftClient mc) {
                ServerInfo si = mc.getCurrentServerEntry();
                return si == null ? "un jugador" : si.address;
            }
        },
        new ArmorModule(),
        new Feature("zoom", "Zoom", "Mantén la tecla de zoom para acercar.", "Visual", true).value("Nivel de zoom", 1.5f, 10f, 4f),
        new Feature("fullbright", "Fullbright", "Ve claro en cuevas y de noche.", "Visual", false)
    );

    public static HudModule byId(String id) {
        for (HudModule m : MODULES) if (m.id.equals(id)) return m;
        return null;
    }

    // ---------- Render ----------
    private static long lastNs = System.nanoTime();

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        Cps.poll(mc);
        long n = System.nanoTime();
        float dt = Math.min(0.1f, (n - lastNs) / 1e9f);
        lastNs = n;
        Features.frame(mc, dt);
        if (mc.options.hudHidden) {
            Welcome.render(ctx, mc);
            return;
        }
        for (HudModule m : MODULES) {
            if (!m.hud) continue;
            float target = m.cfg.enabled ? 1f : 0f;
            m.vis = AmetraConfig.animations ? m.vis + (target - m.vis) * Math.min(1f, dt * 10f) : target;
            if (Math.abs(target - m.vis) < 0.01f) m.vis = target;
            drawModule(ctx, mc, m);
        }
        Welcome.render(ctx, mc);
    }

    private static void drawModule(DrawContext ctx, MinecraftClient mc, HudModule m) {
        float a = AmetraConfig.animations ? Colors.ease(m.vis) : m.vis;
        if (a < 0.05f) return;
        int color = m.cfg.chroma ? Colors.hsv((System.currentTimeMillis() % 4000L) / 4000f, 0.6f, 1f) : m.cfg.color;
        float slide = AmetraConfig.animations ? (1f - a) * -10f : 0f;
        MatrixStack ms = ctx.getMatrices();
        ms.push();
        ms.translate(m.cfg.x + slide, m.cfg.y, 0f);
        ms.scale(m.cfg.scale, m.cfg.scale, 1f);
        m.draw(ctx, mc, a, color);
        ms.pop();
    }
}
