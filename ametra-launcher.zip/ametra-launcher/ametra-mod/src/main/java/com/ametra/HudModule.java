package com.ametra;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Un módulo del cliente: puede ser un elemento del HUD o una función (zoom, fullbright). */
public abstract class HudModule {
    public final String id, name, desc, cat;
    public final int defX, defY;
    public final boolean defEnabled;
    public ModuleCfg cfg = new ModuleCfg();
    /** false = función sin dibujo en pantalla (no se puede mover). */
    public boolean hud = true;
    public String valueLabel;
    public float vMin, vMax, vDef;
    /** Animación de aparición (0 = oculto, 1 = visible). */
    public float vis;
    /** Tamaño medido en el último dibujo (sin escalar). */
    public int w = 60, h = 16;

    protected HudModule(String id, String name, String desc, String cat, int defX, int defY, boolean defEnabled) {
        this.id = id;
        this.name = name;
        this.desc = desc;
        this.cat = cat;
        this.defX = defX;
        this.defY = defY;
        this.defEnabled = defEnabled;
    }

    public HudModule value(String label, float min, float max, float def) {
        this.valueLabel = label;
        this.vMin = min;
        this.vMax = max;
        this.vDef = def;
        return this;
    }

    public boolean hasValue() {
        return valueLabel != null;
    }

    public void resetPos() {
        cfg.x = defX;
        cfg.y = defY;
    }

    /** Dibuja en (0,0) local (posición y escala ya aplicadas) y actualiza w/h. */
    public abstract void draw(DrawContext ctx, MinecraftClient mc, float alpha, int color);
}
