package com.ametra;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

import org.lwjgl.glfw.GLFW;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.fabricmc.loader.api.metadata.ModMetadata;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;

/**
 * Menú de Ametra (estilo Feather/Lunar): barra lateral, buscador, categorías, rejilla de tarjetas,
 * favoritos y panel lateral de ajustes. Todo se dibuja a mano con "hit regions" que se recrean cada frame.
 */
public class AmetraScreen extends Screen {
    static final String VERSION = "v1.0.0";

    // ---- Layout (coordenadas locales del panel) ----
    static final int PW = 540, PH = 320, SIDE = 124, MX = SIDE + 1, PAD = 14;
    static final int GX = MX + PAD, GW = PW - MX - 2 * PAD;
    static final int CARD_W = 123, CARD_H = 76, GAP = 9, ROWGAP = 8;
    static final int TOP0 = 66, TOP1 = 46, BOTTOM = 10, DW = 206;

    // ---- Colores ----
    static final int BG = 0x0C0C12, BG2 = 0x151520, BG3 = 0x1E1E2C, LINE = 0x2A2A3A, TEXT = 0xF2F2F6, MUTED = 0x8E8E9E;
    static final int[] MOD_PRESETS = {0xFFFFFF, 0x8FD6A8, 0x85C1E9, 0xD7A8F0, 0xF1948A, 0xF0B27A, 0xFFD93D, 0xFF5C8A};
    static final int[] ACC_PRESETS = {
        0x8FD6A8, 0x6FCF97, 0x85C1E9, 0x56CCF2, 0xD7A8F0, 0xBB6BD9, 0xF1948A, 0xEB5757,
        0xF0B27A, 0xF2994A, 0xFFD93D, 0xF2C94C, 0xFF5C8A, 0x00E5FF, 0xFFFFFF, 0x9B8CFF};
    static final String[] TABS = {"Módulos", "Tema", "Instalados"};
    static final String[] CATS = {"Todos", "Info", "Combate", "Visual", "Favoritos"};
    static final String[] STAR = {"...#...", "...#...", "#######", ".#####.", "..###..", ".##.##.", ".#...#."};
    static final int PN = 60;

    interface DragFn { void on(float lx, float ly); }

    static final class Hit {
        float x, y, w, h;
        float[] clip;
        Runnable click;
        DragFn drag;
    }

    static final class ModInfo {
        String id, name, ver;
        int color;
    }

    private static final float[] NONE = {-1e9f, -1e9f, 1e9f, 1e9f};

    private final Screen parent;
    private int tab = 0, cat = 0;
    private boolean edit = false, closing = false, closed = false, armed = false;
    private float open = 0f, editFade = 0f, time = 0f, tabAge = 0f, dt = 0.016f;
    private long lastNs = System.nanoTime();
    private float ls = 1f, pa = 1f, lmx, lmy;

    private String search = "";
    private boolean searchFocus = false;
    private HudModule drawerMod = null, dragging = null;
    private boolean drawerOpen = false;
    private float dragOffX, dragOffY;
    private final float[] scroll = new float[3], scrollT = new float[3];
    private float contentH = 0f;
    private boolean noHit = false;

    private final Map<String, Float> anims = new HashMap<>();
    private final List<Hit> hits = new ArrayList<>();
    private Hit active;
    private final ArrayDeque<float[]> clipStack = new ArrayDeque<>();
    private float[] clipNow = NONE;

    private float aH, aS, aV; // acento en HSV (conserva el tono aunque S o V sean 0)
    private List<ModInfo> mods;
    private final float[] pnx = new float[PN], pny = new float[PN], psp = new float[PN], pph = new float[PN];

    public AmetraScreen(Screen parent) {
        super(Text.literal("Ametra"));
        this.parent = parent;
        Random r = new Random(7);
        for (int i = 0; i < PN; i++) {
            pnx[i] = r.nextFloat();
            pny[i] = r.nextFloat();
            psp[i] = 0.02f + r.nextFloat() * 0.05f;
            pph[i] = r.nextFloat() * 6.28f;
        }
        armed = parent != null; // abierto desde un botón: la tecla no está pulsada
    }

    @Override
    protected void init() {
        if (mods == null) mods = loadMods();
        float[] hsv = Colors.toHsv(AmetraConfig.accent);
        aH = hsv[0];
        aS = hsv[1];
        aV = hsv[2];
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void removed() {
        AmetraConfig.save();
    }

    @Override
    public void close() {
        if (closing || closed) return;
        if (!AmetraConfig.animations) {
            closed = true;
            AmetraConfig.save();
            client.setScreen(parent);
            return;
        }
        closing = true;
    }

    // ---------- Mods instalados ----------
    private static List<ModInfo> loadMods() {
        List<ModInfo> out = new ArrayList<>();
        int[] pal = {0x8FD6A8, 0x85C1E9, 0xD7A8F0, 0xF1948A, 0xF0B27A, 0xFFD93D, 0xFF5C8A, 0x56CCF2};
        for (ModContainer c : FabricLoader.getInstance().getAllMods()) {
            ModMetadata md = c.getMetadata();
            String id = md.getId();
            if (c.getContainingMod().isPresent()) continue;
            if ("builtin".equals(md.getType())) continue;
            if (id.equals("fabricloader") || id.equals("mixinextras") || (id.startsWith("fabric-") && !id.equals("fabric-api"))) continue;
            ModInfo mi = new ModInfo();
            mi.id = id;
            mi.name = md.getName() == null || md.getName().isBlank() ? id : md.getName();
            mi.ver = md.getVersion().getFriendlyString();
            mi.color = pal[Math.abs(id.hashCode()) % pal.length];
            out.add(mi);
        }
        out.sort(Comparator.comparing(m -> m.name.toLowerCase(Locale.ROOT)));
        return out;
    }

    // ---------- Helpers ----------
    private float an(String k, float target, float speed) {
        float v = anims.getOrDefault(k, target);
        v += (target - v) * Math.min(1f, dt * speed);
        if (Math.abs(target - v) < 0.002f) v = target;
        anims.put(k, v);
        return v;
    }

    private static float approach(float v, float target, float step) {
        return v < target ? Math.min(target, v + step) : Math.max(target, v - step);
    }

    private float tx() { return width / 2f; }
    private float ty() { return height / 2f + (1f - Colors.ease(open)) * 10f; }
    private float toLX(double mx) { return (float) ((mx - tx()) / ls + PW / 2f); }
    private float toLY(double my) { return (float) ((my - ty()) / ls + PH / 2f); }
    private float toSX(float lx) { return (lx - PW / 2f) * ls + tx(); }
    private float toSY(float ly) { return (ly - PH / 2f) * ls + ty(); }

    private boolean over(float x, float y, float w, float h) {
        return lmx >= x && lmx < x + w && lmy >= y && lmy < y + h
            && lmx >= clipNow[0] && lmx < clipNow[2] && lmy >= clipNow[1] && lmy < clipNow[3];
    }

    private void hit(float x, float y, float w, float h, Runnable click, DragFn drag) {
        if (noHit) return;
        Hit t = new Hit();
        t.x = x; t.y = y; t.w = w; t.h = h; t.clip = clipNow; t.click = click; t.drag = drag;
        hits.add(t);
    }

    private void pushClip(DrawContext ctx, float x1, float y1, float x2, float y2) {
        float[] n = {Math.max(x1, clipNow[0]), Math.max(y1, clipNow[1]), Math.min(x2, clipNow[2]), Math.min(y2, clipNow[3])};
        clipStack.push(clipNow);
        clipNow = n;
        ctx.enableScissor((int) Math.floor(toSX(x1)), (int) Math.floor(toSY(y1)), (int) Math.ceil(toSX(x2)), (int) Math.ceil(toSY(y2)));
    }

    private void popClip(DrawContext ctx) {
        ctx.disableScissor();
        clipNow = clipStack.pop();
    }

    // Wrappers con la transparencia global del panel
    private void box(DrawContext c, float x, float y, float w, float h, int rgb, float a) { Gfx.rbox(c, x, y, w, h, rgb, a * pa); }
    private void rect(DrawContext c, float x, float y, float w, float h, int rgb, float a) { Gfx.rect(c, x, y, w, h, rgb, a * pa); }
    private void ol(DrawContext c, float x, float y, float w, float h, int rgb, float a) { Gfx.outline(c, x, y, w, h, rgb, a * pa); }
    private void txt(DrawContext c, String s, float x, float y, int rgb, float a) { Gfx.text(c, s, x, y, rgb, a * pa, false); }

    private String trim(String s, int maxW) {
        if (Gfx.width(s) <= maxW) return s;
        while (s.length() > 1 && Gfx.width(s + "...") > maxW) s = s.substring(0, s.length() - 1);
        return s + "...";
    }

    private List<String> wrap(String s, int maxW, int maxLines) {
        List<String> lines = new ArrayList<>();
        String cur = "";
        for (String word : s.split(" ")) {
            String t = cur.isEmpty() ? word : cur + " " + word;
            if (Gfx.width(t) <= maxW) { cur = t; continue; }
            lines.add(cur);
            cur = word;
            if (lines.size() == maxLines) break;
        }
        if (lines.size() < maxLines && !cur.isEmpty()) lines.add(cur);
        return lines;
    }

    private boolean menuKeyDown() {
        try {
            InputUtil.Key k = KeyBindingHelper.getBoundKeyOf(AmetraClient.MENU_KEY);
            if (k.getCategory() == InputUtil.Type.KEYSYM) return InputUtil.isKeyPressed(client.getWindow().getHandle(), k.getCode());
        } catch (Exception ignored) { /* sin tecla */ }
        return false;
    }

    private float rowA(int i) {
        return Colors.ease(tabAge * 6f - i * 0.25f);
    }

    private void setTab(int i) {
        if (tab == i) return;
        tab = i;
        tabAge = 0f;
        searchFocus = false;
    }

    private void setCat(int i) {
        cat = i;
        scrollT[0] = 0f;
        tabAge = 0f;
    }

    private void openDrawer(HudModule m) {
        if (drawerOpen && drawerMod == m) { drawerOpen = false; return; }
        drawerMod = m;
        drawerOpen = true;
    }

    private void toggleFav(String id) {
        if (!AmetraConfig.favorites.remove(id)) AmetraConfig.favorites.add(id);
        AmetraConfig.save();
    }

    private List<HudModule> filtered() {
        String q = search.toLowerCase(Locale.ROOT).trim();
        List<HudModule> favs = new ArrayList<>(), rest = new ArrayList<>();
        for (HudModule m : Hud.MODULES) {
            boolean fav = AmetraConfig.favorites.contains(m.id);
            if (cat == 4 && !fav) continue;
            if (cat >= 1 && cat <= 3 && !m.cat.equals(CATS[cat])) continue;
            if (!q.isEmpty() && !m.name.toLowerCase(Locale.ROOT).contains(q) && !m.desc.toLowerCase(Locale.ROOT).contains(q)) continue;
            (fav ? favs : rest).add(m);
        }
        favs.addAll(rest);
        return favs;
    }

    // ---------- Render ----------
    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        long nn = System.nanoTime();
        dt = Math.min(0.1f, (nn - lastNs) / 1e9f);
        lastNs = nn;
        time += dt;
        tabAge += dt;
        boolean anim = AmetraConfig.animations;
        if (!armed && !menuKeyDown()) armed = true;

        if (closing) open = anim ? Math.max(0f, open - dt * 7f) : 0f;
        else open = anim ? Math.min(1f, open + dt * 4.5f) : 1f;
        if (closing && open <= 0f && !closed) {
            closed = true;
            AmetraConfig.save();
            client.execute(() -> client.setScreen(parent));
        }
        editFade = anim ? approach(editFade, edit ? 1f : 0f, dt * 7f) : (edit ? 1f : 0f);

        float oe = Colors.ease(open);
        float fit = Math.min(1f, Math.min(width / (PW + 24f), height / (PH + 24f)));
        ls = fit * (0.9f + 0.1f * oe);
        pa = oe * (1f - editFade);
        lmx = toLX(mouseX);
        lmy = toLY(mouseY);
        hits.clear();
        clipStack.clear();
        clipNow = NONE;
        noHit = false;

        int ac = AmetraConfig.accent;
        float dim = oe * (1f - 0.8f * editFade);
        ctx.fillGradient(0, 0, width, height, Colors.argb(0x04040A, 0.60f * dim), Colors.argb(0x0A0A18, 0.82f * dim));
        ctx.fillGradient(0, height * 2 / 3, width, height, Colors.argb(ac, 0f), Colors.argb(ac, 0.12f * dim));
        for (int i = 0; i < PN; i++) {
            float y = (((pny[i] - time * psp[i]) % 1f) + 1f) % 1f;
            float x = pnx[i] * width + (float) Math.sin(time * 0.6f + pph[i]) * 10f;
            float tw = 0.5f + 0.5f * (float) Math.sin(time * 1.5f + pph[i] * 3f);
            Gfx.rect(ctx, x, y * height, (i % 5 == 0) ? 2 : 1, (i % 5 == 0) ? 2 : 1, ac, (0.10f + 0.35f * tw) * dim);
        }

        if (pa > 0.02f) drawPanel(ctx, ac);
        if (editFade > 0.02f) drawEdit(ctx, mouseX, mouseY, ac);
    }

    private void drawPanel(DrawContext ctx, int ac) {
        MatrixStack ms = ctx.getMatrices();
        ms.push();
        ms.translate(tx(), ty(), 0f);
        ms.scale(ls, ls, 1f);
        ms.translate(-PW / 2f, -PH / 2f, 0f);

        box(ctx, -4, -4, PW + 8, PH + 8, ac, 0.07f);
        box(ctx, -1, -1, PW + 2, PH + 2, LINE, 1f);
        box(ctx, 0, 0, PW, PH, BG, 0.97f);
        rect(ctx, 1, 1, SIDE - 1, PH - 2, BG2, 0.85f);
        rect(ctx, SIDE, 1, 1, PH - 2, LINE, 1f);

        drawSidebar(ctx, ac);

        // Botón cerrar
        float cl = an("close", over(PW - 30, 8, 20, 20) ? 1f : 0f, 14f);
        box(ctx, PW - 30, 8, 20, 20, Colors.lerp(BG2, 0xC4384B, cl), 1f);
        txt(ctx, "×", PW - 30 + (20 - Gfx.width("×")) / 2f, 14, Colors.lerp(MUTED, 0xFFFFFF, cl), 1f);
        hit(PW - 30, 8, 20, 20, this::close, null);

        float top = tab == 0 ? TOP0 : TOP1;
        if (tab == 0) drawTopBar(ctx, ac);
        else Gfx.textScaled(ctx, tab == 1 ? "Tema" : "Mods instalados", GX, 14, 1.35f, TEXT, pa, true);

        float ch = PH - BOTTOM - top;
        pushClip(ctx, GX - 4, top, GX + GW + 4, PH - BOTTOM);
        float y0 = top - scroll[tab];
        if (tab == 0) tabGrid(ctx, y0, ac);
        else if (tab == 1) tabTheme(ctx, y0, ac);
        else tabMods(ctx, y0, ac);
        popClip(ctx);

        float maxS = Math.max(0f, contentH - ch);
        scrollT[tab] = Math.max(0f, Math.min(maxS, scrollT[tab]));
        scroll[tab] += (scrollT[tab] - scroll[tab]) * Math.min(1f, dt * 14f);
        if (maxS > 0f) {
            float th = Math.max(24f, ch * ch / contentH);
            float tyy = top + (ch - th) * (scroll[tab] / maxS);
            rect(ctx, GX + GW + 6, top, 2, ch, LINE, 0.8f);
            rect(ctx, GX + GW + 6, tyy, 2, th, ac, 0.9f);
        }

        drawDrawer(ctx, ac);
        ms.pop();
    }

    // ---------- Barra lateral ----------
    private void drawSidebar(DrawContext ctx, int ac) {
        float pulse = 1f + 0.05f * (float) Math.sin(time * 2.2f);
        float size = 34f * pulse;
        Gfx.glow(ctx, 30, 32, 24 + 2 * (float) Math.sin(time * 2.2f), ac, 0.5f * pa);
        Gfx.logo(ctx, 30 - size / 2f, 32 - size / 2f, size, pa);
        Gfx.textScaled(ctx, "AMETRA", 54, 21, 1.3f, ac, pa, true);
        txt(ctx, "CLIENT", 55, 35, MUTED, 1f);
        // línea con destello
        rect(ctx, 12, 54, SIDE - 24, 1, LINE, 1f);
        float shx = (time * 70f) % (SIDE + 40) - 20f;
        float xa = Math.max(12, shx), xb = Math.min(SIDE - 12, shx + 28f);
        if (xb > xa) rect(ctx, xa, 54, xb - xa, 1, ac, 0.9f);

        float ti = an("tab", tab, 14f);
        float pyT = TOP0 + ti * 32f;
        box(ctx, 8, pyT, SIDE - 16, 28, ac, 0.16f);
        rect(ctx, 8, pyT + 6, 2, 16, ac, 1f);
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            float y = TOP0 + i * 32f;
            float hv = an("th" + i, over(8, y, SIDE - 16, 28) ? 1f : 0f, 14f);
            float sel = Colors.clamp01(1f - Math.abs(ti - i));
            txt(ctx, TABS[i], 20 + hv * 2f, y + 10, Colors.lerp(Colors.lerp(MUTED, TEXT, hv), ac, sel), 1f);
            if (i == 2 && mods != null) {
                String n = String.valueOf(mods.size());
                txt(ctx, n, SIDE - 16 - Gfx.width(n), y + 10, MUTED, 1f);
            }
            hit(8, y, SIDE - 16, 28, () -> setTab(idx), null);
        }

        boolean inWorld = client != null && client.player != null;
        float bx = 10, by = PH - 92, bw = SIDE - 20;
        float hv = an("editbtn", inWorld && over(bx, by, bw, 24) ? 1f : 0f, 14f);
        box(ctx, bx, by, bw, 24, Colors.lerp(BG3, ac, hv * 0.35f), 1f);
        ol(ctx, bx, by, bw, 24, ac, 0.25f + 0.5f * hv);
        String el = "Mover HUD";
        txt(ctx, el, bx + (bw - Gfx.width(el)) / 2f, by + 8, inWorld ? TEXT : MUTED, 1f);
        if (inWorld) hit(bx, by, bw, 24, () -> { edit = true; dragging = null; drawerOpen = false; }, null);
        else txt(ctx, "Entra a un mundo", bx + 6, by + 29, MUTED, 0.8f);

        String key = AmetraClient.MENU_KEY.getBoundKeyLocalizedText().getString();
        txt(ctx, trim(key + " = cerrar", SIDE - 20), 12, PH - 32, MUTED, 0.9f);
        txt(ctx, "Ametra " + VERSION, 12, PH - 20, MUTED, 0.7f);
    }

    // ---------- Barra superior (buscador + categorías) ----------
    private void drawTopBar(DrawContext ctx, int ac) {
        float sw = 176;
        float fk = an("searchf", searchFocus ? 1f : 0f, 14f);
        box(ctx, GX, 10, sw, 22, BG2, 1f);
        ol(ctx, GX, 10, sw, 22, Colors.lerp(LINE, ac, fk), 1f);
        // lupa en píxeles
        ol(ctx, GX + 8, 16, 7, 7, Colors.lerp(MUTED, ac, fk), 1f);
        rect(ctx, GX + 15, 23, 3, 1, Colors.lerp(MUTED, ac, fk), 1f);
        if (search.isEmpty() && !searchFocus) txt(ctx, "Buscar módulos...", GX + 24, 17, MUTED, 0.8f);
        else txt(ctx, trim(search, (int) sw - 34), GX + 24, 17, TEXT, 1f);
        if (searchFocus && ((int) (time * 2f)) % 2 == 0) {
            rect(ctx, GX + 24 + Math.min(Gfx.width(search), sw - 34), 15, 1, 11, ac, 1f);
        }
        hit(GX, 10, sw, 22, () -> searchFocus = true, null);

        float x = GX;
        for (int i = 0; i < CATS.length; i++) {
            final int idx = i;
            String label = CATS[i];
            float cw = Gfx.width(label) + 18;
            float hv = an("cat" + i, over(x, 40, cw, 18) ? 1f : 0f, 14f);
            float sel = an("catsel" + i, cat == i ? 1f : 0f, 14f);
            box(ctx, x, 40, cw, 18, Colors.lerp(Colors.lerp(BG2, BG3, hv), ac, sel * 0.22f), 1f);
            ol(ctx, x, 40, cw, 18, ac, 0.55f * sel);
            txt(ctx, label, x + 9, 45, Colors.lerp(Colors.lerp(MUTED, TEXT, hv), ac, sel), 1f);
            hit(x, 40, cw, 18, () -> setCat(idx), null);
            x += cw + 6;
        }
    }

    // ---------- Widgets ----------
    private void toggle(DrawContext ctx, String id, float x, float y, boolean on, float a, Runnable r) {
        float k = an("tg:" + id, on ? 1f : 0f, 16f);
        box(ctx, x, y, 22, 12, Colors.lerp(0x2E2E3E, AmetraConfig.accent, k), a);
        box(ctx, x + 2 + k * 10f, y + 2, 8, 8, Colors.lerp(0x9A9AAA, 0xFFFFFF, k), a);
        hit(x - 2, y - 2, 26, 16, r, null);
    }

    private void button(DrawContext ctx, String id, String label, float x, float y, float w, float h, boolean enabled, float a, Runnable r) {
        float hv = an("bt:" + id, enabled && over(x, y, w, h) ? 1f : 0f, 14f);
        box(ctx, x, y, w, h, Colors.lerp(BG3, AmetraConfig.accent, hv * 0.30f), a);
        ol(ctx, x, y, w, h, AmetraConfig.accent, a * (0.25f + 0.5f * hv));
        txt(ctx, label, x + (w - Gfx.width(label)) / 2f, y + (h - 8) / 2f, enabled ? TEXT : MUTED, a);
        if (enabled) hit(x, y, w, h, r, null);
    }

    private void slider(DrawContext ctx, String id, float x, float y, float w, float min, float max, float val, float a, Consumer<Float> set) {
        float f = Colors.clamp01((val - min) / (max - min));
        box(ctx, x, y + 5, w, 4, 0x2A2A3A, a);
        box(ctx, x, y + 5, Math.max(2f, w * f), 4, AmetraConfig.accent, a);
        float hv = an("sl:" + id, over(x - 4, y, w + 8, 14) ? 1f : 0f, 14f);
        box(ctx, x + w * f - 3, y + 1, 6, 12, Colors.lerp(0xD0D0DA, 0xFFFFFF, hv), a);
        hit(x - 4, y, w + 8, 14, null, (lx, ly) -> {
            float v = min + Colors.clamp01((lx - x) / w) * (max - min);
            set.accept(Math.round(v * 20f) / 20f);
        });
    }

    private void hueBar(DrawContext ctx, float x, float y, float w, float h, float hue, boolean marker, float a, Consumer<Float> set) {
        int seg = Math.max(1, Math.round(w / 2f));
        for (int i = 0; i < seg; i++) {
            float xa = x + w * i / seg, xb = x + w * (i + 1) / seg;
            rect(ctx, xa, y, xb - xa, h, Colors.hsv((i + 0.5f) / seg, 1f, 1f), a);
        }
        if (marker) {
            rect(ctx, x + w * hue - 1.5f, y - 2, 3, h + 4, 0x000000, a);
            rect(ctx, x + w * hue - 0.5f, y - 2, 1, h + 4, 0xFFFFFF, a);
        }
        hit(x - 2, y - 2, w + 4, h + 4, null, (lx, ly) -> set.accept(Colors.clamp01((lx - x) / w)));
    }

    private void svBox(DrawContext ctx, float x, float y, float w, float h, float hue, float s, float v, float a, BiConsumer<Float, Float> set) {
        int cols = Math.round(w / 2f);
        for (int i = 0; i < cols; i++) {
            float xa = x + w * i / cols, xb = x + w * (i + 1) / cols;
            float sat = (i + 0.5f) / cols;
            ctx.fillGradient(Math.round(xa), Math.round(y), Math.round(xb), Math.round(y + h),
                Colors.argb(Colors.hsv(hue, sat, 1f), a * pa), Colors.argb(0x000000, a * pa));
        }
        float mx = x + s * (w - 1), my = y + (1f - v) * (h - 1);
        ol(ctx, mx - 3, my - 3, 7, 7, 0x000000, a);
        ol(ctx, mx - 2, my - 2, 5, 5, 0xFFFFFF, a);
        hit(x, y, w, h, null, (lx, ly) -> set.accept(Colors.clamp01((lx - x) / w), 1f - Colors.clamp01((ly - y) / h)));
    }

    private void star(DrawContext ctx, float x, float y, int rgb, float a) {
        for (int r = 0; r < STAR.length; r++)
            for (int c = 0; c < STAR[r].length(); c++)
                if (STAR[r].charAt(c) == '#') rect(ctx, x + c, y + r, 1, 1, rgb, a);
    }

    // ---------- Pestaña: rejilla de módulos ----------
    private void tabGrid(DrawContext ctx, float y0, int ac) {
        List<HudModule> list = filtered();
        if (list.isEmpty()) {
            String m = "No hay módulos que coincidan.";
            txt(ctx, m, GX + (GW - Gfx.width(m)) / 2f, y0 + 60, MUTED, 1f);
            contentH = 0f;
            return;
        }
        for (int i = 0; i < list.size(); i++) {
            int col = i % 3, row = i / 3;
            card(ctx, list.get(i), GX + col * (CARD_W + GAP), y0 + row * (CARD_H + ROWGAP) + (1f - rowA(i)) * 10f, rowA(i), ac);
        }
        int rows = (list.size() + 2) / 3;
        contentH = rows * (CARD_H + ROWGAP);
    }

    private void card(DrawContext ctx, HudModule m, float x, float y, float ra, int ac) {
        ModuleCfg c = m.cfg;
        float hv = an("ch:" + m.id, over(x, y, CARD_W, CARD_H) ? 1f : 0f, 14f);
        float en = an("cen:" + m.id, c.enabled ? 1f : 0f, 12f);
        float sl = an("csel:" + m.id, drawerOpen && drawerMod == m ? 1f : 0f, 14f);
        float yy = y - hv;

        hit(x, y, CARD_W, CARD_H, () -> openDrawer(m), null);
        box(ctx, x, yy, CARD_W, CARD_H, Colors.lerp(BG2, BG3, hv), ra);
        ol(ctx, x, yy, CARD_W, CARD_H, ac, ra * (0.08f + 0.22f * en + 0.5f * sl));
        rect(ctx, x + 6, yy, CARD_W - 12, 2, ac, ra * en);

        // icono
        box(ctx, x + 8, yy + 10, 24, 24, Colors.lerp(0x2A2A3A, ac, en), ra);
        String l = m.name.substring(0, 1);
        Gfx.textScaled(ctx, l, x + 8 + (24 - Gfx.width(l) * 1.4f) / 2f, yy + 16, 1.4f, Colors.lerp(MUTED, 0x0A0A12, en), ra * pa, false);

        // ajustes (tres puntos) y favorito
        float gx = x + CARD_W - 40, gy = yy + 14;
        float gh = an("gear:" + m.id, over(gx - 3, gy - 5, 17, 14) ? 1f : 0f, 14f);
        int gc = Colors.lerp(MUTED, TEXT, gh);
        for (int i = 0; i < 3; i++) rect(ctx, gx + i * 4, gy, 2, 2, gc, ra);
        hit(gx - 3, gy - 5, 17, 14, () -> openDrawer(m), null);

        float sx = x + CARD_W - 20, sy = yy + 10;
        float fk = an("fav:" + m.id, AmetraConfig.favorites.contains(m.id) ? 1f : 0f, 14f);
        star(ctx, sx, sy, Colors.lerp(0x4A4A5E, ac, fk), ra);
        hit(sx - 2, sy - 2, 11, 11, () -> toggleFav(m.id), null);

        txt(ctx, m.name, x + 8, yy + 40, TEXT, ra);
        txt(ctx, trim(m.desc, CARD_W - 16), x + 8, yy + 52, MUTED, ra * 0.85f);
        txt(ctx, m.cat.toUpperCase(Locale.ROOT), x + 8, yy + 64, Colors.lerp(0x5E5E72, ac, en * 0.7f), ra * 0.9f);
        toggle(ctx, "m:" + m.id, x + CARD_W - 30, yy + 61, c.enabled, ra, () -> { c.enabled = !c.enabled; AmetraConfig.save(); });
    }

    // ---------- Panel lateral de ajustes ----------
    private void drawDrawer(DrawContext ctx, int ac) {
        float k = an("drawer", drawerOpen ? 1f : 0f, 12f);
        if (k <= 0.01f && !drawerOpen) { drawerMod = null; return; }
        if (drawerMod == null) return;
        HudModule m = drawerMod;
        ModuleCfg c = m.cfg;
        float e = Colors.ease(k);
        float x = PW - DW * e;
        box(ctx, x - 1, 1, DW + 1, PH - 2, LINE, k);
        box(ctx, x, 1, DW, PH - 2, 0x10101A, 0.99f * k);
        noHit = k < 0.85f;
        hit(x, 0, DW + 2, PH, () -> { }, null); // bloquea clics hacia la rejilla

        float ox = x + 16, w = DW - 32;
        Gfx.bold(ctx, m.name, ox, 16, TEXT, k * pa, true);
        float cx = an("dx", over(x + DW - 30, 10, 18, 18) ? 1f : 0f, 14f);
        txt(ctx, "×", x + DW - 26, 14, Colors.lerp(MUTED, TEXT, cx), k);
        hit(x + DW - 30, 10, 18, 18, () -> drawerOpen = false, null);

        float y = 34;
        List<String> lines = wrap(m.desc, (int) w, 3);
        for (String ln : lines) { txt(ctx, ln, ox, y, MUTED, k); y += 10; }
        y += 6;

        txt(ctx, "Activado", ox, y + 2, TEXT, k);
        toggle(ctx, "dm:" + m.id, ox + w - 22, y, c.enabled, k, () -> { c.enabled = !c.enabled; AmetraConfig.save(); });
        y += 24;

        if (m.hasValue()) {
            txt(ctx, m.valueLabel, ox, y, MUTED, k);
            txt(ctx, String.format(Locale.ROOT, "%.1fx", c.value), ox + w - Gfx.width(String.format(Locale.ROOT, "%.1fx", c.value)), y, TEXT, k);
            slider(ctx, "val:" + m.id, ox, y + 10, w, m.vMin, m.vMax, c.value, k, v -> c.value = v);
            y += 32;
            if (m.id.equals("zoom") && Features.ZOOM_KEY != null) {
                txt(ctx, "Tecla: " + Features.ZOOM_KEY.getBoundKeyLocalizedText().getString() + " (cámbiala en Controles)", ox, y, MUTED, k * 0.9f);
                y += 14;
            }
        }

        if (m.hud) {
            txt(ctx, "Color", ox, y, MUTED, k);
            float sy = y + 12;
            for (int i = 0; i < MOD_PRESETS.length; i++) {
                final int col = MOD_PRESETS[i];
                float bx = ox + i * 22;
                boolean sel = !c.chroma && c.color == col;
                float hv = an("dsw:" + i, over(bx, sy, 16, 14) ? 1f : 0f, 14f);
                box(ctx, bx, sy, 16, 14, col, k);
                if (sel) ol(ctx, bx - 2, sy - 2, 20, 18, TEXT, k);
                else ol(ctx, bx - 1, sy - 1, 18, 16, TEXT, k * hv * 0.6f);
                hit(bx, sy, 16, 14, () -> { c.color = col; c.chroma = false; AmetraConfig.save(); }, null);
            }
            hueBar(ctx, ox, sy + 22, w, 12, Colors.toHsv(c.color)[0], !c.chroma, k, hue -> { c.color = Colors.hsv(hue, 1f, 1f); c.chroma = false; });
            y = sy + 44;

            txt(ctx, "Chroma", ox, y + 2, MUTED, k);
            toggle(ctx, "dch:" + m.id, ox + 44, y, c.chroma, k, () -> { c.chroma = !c.chroma; AmetraConfig.save(); });
            txt(ctx, "Fondo", ox + 92, y + 2, MUTED, k);
            toggle(ctx, "dbg:" + m.id, ox + 126, y, c.bg, k, () -> { c.bg = !c.bg; AmetraConfig.save(); });
            y += 20;
            txt(ctx, "Sombra", ox, y + 2, MUTED, k);
            toggle(ctx, "dsh:" + m.id, ox + 44, y, c.shadow, k, () -> { c.shadow = !c.shadow; AmetraConfig.save(); });
            y += 22;

            txt(ctx, "Escala", ox, y, MUTED, k);
            String sc = String.format(Locale.ROOT, "%.2fx", c.scale);
            txt(ctx, sc, ox + w - Gfx.width(sc), y, TEXT, k);
            slider(ctx, "dsc:" + m.id, ox, y + 10, w, 0.5f, 2f, c.scale, k, v -> c.scale = v);
            y += 32;

            button(ctx, "dmove", "Mover en pantalla", ox, y, w, 18, client != null && client.player != null, k, () -> { edit = true; drawerOpen = false; });
            button(ctx, "dreset", "Reiniciar posición", ox, y + 22, w, 18, true, k, () -> { m.resetPos(); AmetraConfig.save(); });
        }
        noHit = false;
    }

    // ---------- Pestaña: Tema ----------
    private void applyAccent() {
        AmetraConfig.accent = Colors.hsv(aH, aS, aV);
    }

    private void tabTheme(DrawContext ctx, float y0, int ac) {
        float a = Colors.ease(tabAge * 6f);
        txt(ctx, "COLOR DE ACENTO", GX, y0, MUTED, a);
        float by = y0 + 14;

        svBox(ctx, GX, by, 150, 70, aH, aS, aV, a, (s, v) -> { aS = s; aV = v; applyAccent(); });
        hueBar(ctx, GX, by + 78, 150, 10, aH, true, a, h -> { aH = h; applyAccent(); });

        float px = GX + 172;
        box(ctx, px, by, 44, 44, ac, a);
        txt(ctx, Colors.hex(ac), px + 54, by + 9, TEXT, a);
        txt(ctx, "Acento del menú y del HUD", px + 54, by + 23, MUTED, a);
        for (int i = 0; i < ACC_PRESETS.length; i++) {
            final int col = ACC_PRESETS[i];
            float bx = px + (i % 8) * 22, byy = by + 56 + (i / 8) * 20;
            float hv = an("ap" + i, over(bx, byy, 16, 16) ? 1f : 0f, 14f);
            box(ctx, bx, byy, 16, 16, col, a);
            if (col == ac) ol(ctx, bx - 2, byy - 2, 20, 20, TEXT, a);
            else ol(ctx, bx - 1, byy - 1, 18, 18, TEXT, a * hv * 0.6f);
            hit(bx, byy, 16, 16, () -> {
                float[] hsv = Colors.toHsv(col);
                aH = hsv[0]; aS = hsv[1]; aV = hsv[2];
                AmetraConfig.accent = col;
                AmetraConfig.save();
            }, null);
        }

        float t2 = by + 108;
        txt(ctx, "ANIMACIONES Y EFECTOS", GX, t2, MUTED, a);
        float tgx = GX + GW - 30;
        txt(ctx, "Animaciones del menú y del HUD", GX, t2 + 20, TEXT, a);
        toggle(ctx, "anim", tgx, t2 + 18, AmetraConfig.animations, a, () -> { AmetraConfig.animations = !AmetraConfig.animations; AmetraConfig.save(); });
        txt(ctx, "Bienvenida al entrar a un mundo o servidor", GX, t2 + 42, TEXT, a);
        toggle(ctx, "welcome", tgx, t2 + 40, AmetraConfig.welcome, a, () -> { AmetraConfig.welcome = !AmetraConfig.welcome; AmetraConfig.save(); });
        txt(ctx, "Efectos en el menú principal", GX, t2 + 64, TEXT, a);
        toggle(ctx, "titlefx", tgx, t2 + 62, AmetraConfig.titleFx, a, () -> { AmetraConfig.titleFx = !AmetraConfig.titleFx; AmetraConfig.save(); });

        button(ctx, "resetall", "Restablecer posiciones del HUD", GX, t2 + 90, 190, 20, true, a, () -> {
            for (HudModule m : Hud.MODULES) m.resetPos();
            AmetraConfig.save();
        });
        button(ctx, "prevwelcome", "Ver bienvenida", GX + 198, t2 + 90, 110, 20, client != null && client.player != null, a, Welcome::preview);
        contentH = (t2 + 90 + 20 + 6) - y0;
    }

    // ---------- Pestaña: Mods instalados ----------
    private void tabMods(DrawContext ctx, float y0, int ac) {
        float a0 = Colors.ease(tabAge * 6f);
        txt(ctx, mods.size() + " mods instalados en esta instancia", GX, y0, MUTED, a0);
        float y = y0 + 16;
        for (int i = 0; i < mods.size(); i++) {
            ModInfo mi = mods.get(i);
            float ra = rowA(i);
            float x = GX + (1f - ra) * 14f;
            float hv = an("mi:" + mi.id, over(GX, y, GW, 30) ? 1f : 0f, 14f);
            box(ctx, x, y, GW, 30, Colors.lerp(BG2, BG3, hv), ra);
            box(ctx, x + 8, y + 5, 20, 20, mi.color, ra);
            String letter = mi.name.substring(0, 1).toUpperCase(Locale.ROOT);
            txt(ctx, letter, x + 8 + (20 - Gfx.width(letter)) / 2f, y + 11, 0x0A0A12, ra);
            txt(ctx, trim(mi.name, GW - 120), x + 38, y + 6, TEXT, ra);
            txt(ctx, trim(mi.id + "  ·  v" + mi.ver, GW - 120), x + 38, y + 17, MUTED, ra * 0.9f);
            if (mi.id.equals("ametra")) {
                String tag = "CLIENTE";
                float tw = Gfx.width(tag) + 10;
                box(ctx, x + GW - tw - 8, y + 8, tw, 14, ac, 0.2f * ra);
                txt(ctx, tag, x + GW - tw - 3, y + 11, ac, ra);
            }
            y += 34;
        }
        contentH = y - y0;
    }

    // ---------- Editor de posición del HUD ----------
    private void drawEdit(DrawContext ctx, int mx, int my, int ac) {
        float a = editFade;
        String hint = "Arrastra los módulos  ·  Rueda: tamaño  ·  Clic derecho: reiniciar  ·  ESC: volver";
        float hw = Gfx.width(hint) + 24;
        float hx = (width - hw) / 2f;
        Gfx.rbox(ctx, hx - 1, 7, hw + 2, 22, ac, 0.5f * a);
        Gfx.rbox(ctx, hx, 8, hw, 20, 0x0B0B11, 0.94f * a);
        Gfx.text(ctx, hint, hx + 12, 14, TEXT, a, false);

        for (HudModule m : Hud.MODULES) {
            if (!m.hud || !m.cfg.enabled) continue;
            float x = m.cfg.x, y = m.cfg.y, w = m.w * m.cfg.scale, h = m.h * m.cfg.scale;
            boolean hov = mx >= x && mx < x + w && my >= y && my < y + h;
            boolean drag = dragging == m;
            float pulse = 0.5f + 0.25f * (float) Math.sin(time * 4f);
            Gfx.rect(ctx, x - 2, y - 2, w + 4, h + 4, ac, a * (drag ? 0.20f : hov ? 0.12f : 0.05f));
            Gfx.outline(ctx, x - 2, y - 2, w + 4, h + 4, ac, a * (drag ? 1f : hov ? 0.95f : pulse));
            if (hov || drag) {
                String lab = m.name + "  " + Math.round(m.cfg.scale * 100f) + "%";
                float ly = y >= 14 ? y - 14 : y + h + 4;
                Gfx.rbox(ctx, x - 2, ly - 2, Gfx.width(lab) + 8, 12, 0x0B0B11, 0.9f * a);
                Gfx.text(ctx, lab, x + 2, ly, TEXT, a, false);
            }
        }

        float bx = width / 2f - 44, by = height - 36;
        boolean hv = mx >= bx && mx < bx + 88 && my >= by && my < by + 22;
        float k = an("done", hv ? 1f : 0f, 14f);
        Gfx.rbox(ctx, bx, by, 88, 22, Colors.lerp(ac, 0xFFFFFF, k * 0.25f), a);
        Gfx.text(ctx, "Listo", bx + (88 - Gfx.width("Listo")) / 2f, by + 7, 0x0A0A12, a, false);
    }

    private boolean inRect(double mx, double my, float x, float y, float w, float h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    // ---------- Entrada ----------
    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (closing) return true;
        if (edit) {
            if (button == 0 && inRect(mx, my, width / 2f - 44, height - 36, 88, 22)) { edit = false; return true; }
            for (int i = Hud.MODULES.size() - 1; i >= 0; i--) {
                HudModule m = Hud.MODULES.get(i);
                if (!m.hud || !m.cfg.enabled) continue;
                if (inRect(mx, my, m.cfg.x, m.cfg.y, m.w * m.cfg.scale, m.h * m.cfg.scale)) {
                    if (button == 1) { m.resetPos(); AmetraConfig.save(); }
                    else if (button == 0) { dragging = m; dragOffX = (float) mx - m.cfg.x; dragOffY = (float) my - m.cfg.y; }
                    return true;
                }
            }
            return true;
        }
        if (button != 0) return true;
        searchFocus = false;
        float lx = toLX(mx), ly = toLY(my);
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (lx >= h.x && lx < h.x + h.w && ly >= h.y && ly < h.y + h.h
                && lx >= h.clip[0] && lx < h.clip[2] && ly >= h.clip[1] && ly < h.clip[3]) {
                if (h.drag != null) { active = h; h.drag.on(lx, ly); }
                else if (h.click != null) h.click.run();
                return true;
            }
        }
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (edit && dragging != null) {
            float w = dragging.w * dragging.cfg.scale, h = dragging.h * dragging.cfg.scale;
            dragging.cfg.x = Math.round(Math.max(0f, Math.min(width - w, (float) mx - dragOffX)));
            dragging.cfg.y = Math.round(Math.max(0f, Math.min(height - h, (float) my - dragOffY)));
            return true;
        }
        if (active != null && active.drag != null) {
            active.drag.on(toLX(mx), toLY(my));
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        boolean had = active != null || dragging != null;
        active = null;
        dragging = null;
        if (had) AmetraConfig.save();
        return true;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        if (edit) {
            for (int i = Hud.MODULES.size() - 1; i >= 0; i--) {
                HudModule m = Hud.MODULES.get(i);
                if (m.hud && m.cfg.enabled && inRect(mx, my, m.cfg.x, m.cfg.y, m.w * m.cfg.scale, m.h * m.cfg.scale)) {
                    m.cfg.scale = Math.max(0.5f, Math.min(2f, Math.round((m.cfg.scale + (float) vAmount * 0.05f) * 20f) / 20f));
                    AmetraConfig.save();
                    return true;
                }
            }
            return true;
        }
        scrollT[tab] -= (float) vAmount * 30f;
        return true;
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searchFocus && !edit && chr >= 32 && chr != 127 && search.length() < 18) {
            search += chr;
            scrollT[0] = 0f;
            return true;
        }
        return false;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (edit) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) edit = false;
            return true;
        }
        if (searchFocus) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!search.isEmpty()) search = search.substring(0, search.length() - 1);
            } else if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER) {
                searchFocus = false;
            }
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE && drawerOpen) {
            drawerOpen = false;
            return true;
        }
        if (armed && AmetraClient.MENU_KEY.matchesKey(keyCode, scanCode)) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
