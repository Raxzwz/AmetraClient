package com.ametra;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/** Zoom y Fullbright. */
public final class Features {
    private Features() {}

    public static KeyBinding ZOOM_KEY;
    private static float zoomK = 0f;
    private static boolean nvAdded = false;

    /** Divisor del FOV (1 = sin zoom). Lo usa el mixin de GameRenderer. */
    public static float zoomAmount() {
        HudModule z = Hud.byId("zoom");
        if (z == null || !z.cfg.enabled || zoomK <= 0.001f) return 1f;
        return 1f + (z.cfg.value - 1f) * Colors.ease(zoomK);
    }

    /** Se llama cada frame. */
    public static void frame(MinecraftClient mc, float dt) {
        HudModule z = Hud.byId("zoom");
        boolean want = z != null && z.cfg.enabled && ZOOM_KEY != null && ZOOM_KEY.isPressed() && mc.currentScreen == null;
        float target = want ? 1f : 0f;
        zoomK += (target - zoomK) * Math.min(1f, dt * (AmetraConfig.animations ? 12f : 60f));
        if (!want && zoomK < 0.01f) zoomK = 0f;
    }

    /** Se llama cada tick: mantiene visión nocturna del lado cliente si Fullbright está activo. */
    public static void tick(MinecraftClient mc) {
        if (mc.player == null) { nvAdded = false; return; }
        HudModule f = Hud.byId("fullbright");
        boolean want = f != null && f.cfg.enabled;
        if (want) {
            if (!mc.player.hasStatusEffect(StatusEffects.NIGHT_VISION)) {
                mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 100000, 0, false, false, false));
                nvAdded = true;
            }
        } else if (nvAdded) {
            mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
            nvAdded = false;
        }
    }
}
