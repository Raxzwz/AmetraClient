# Changelog

## v1.1.0 — Pack de optimización para todas las versiones
- Nuevo `optimizer.js`: decide loader, mods, Java y flags de JVM según la versión de Minecraft.
- 1.14 en adelante: Fabric + Sodium, Lithium, FerriteCore, ModernFix, Entity Culling, ImmediatelyFast, More Culling, Krypton, Dynamic FPS (y Phosphor/Starlight/LazyDFU donde corresponde). Cada mod se instala solo si existe build para esa versión exacta.
- 1.3.2 – 1.13.2: Legacy Fabric + Legacy Fabric API + los mods de rendimiento más descargados que haya en Modrinth para esa versión.
- 1.0 – 1.3.1: sin loader; solo Java, flags y ajustes de vídeo.
- Java moderno: 1.14–1.17 suben de Java 8/16 a 17, 1.18–1.20.4 de 17 a 21; 1.20.5+ usa lo que pide Mojang (21, 25…). Versiones ≤ 1.13.2 siguen en Java 8 (con Java 9+ no arrancan) pero se exige 8u312 o más nuevo y, si el del PC es más viejo, se descarga el último.
- Flags de JVM (G1 afinado) para todas las versiones.
- Ajustes de vídeo ligeros en la primera ejecución de instancias ≤ 1.12.2 (solo si no existe options.txt).
- Interruptores en Ajustes: pack automático y Java moderno. Tarjeta del pack en la pestaña Cliente con botón "Instalar ahora".
- Los mods se instalan prefiriendo versiones estables (release) sobre beta/alpha.

## v1.0.0 — primera versión
**Launcher**
- Instancias, cuenta Microsoft u offline, Fabric + Fabric API automáticos, perfiles, skin 3D.
- Instala el mod Ametra Client y sincroniza su configuración (módulos y color de acento).

**Ametra Client (Minecraft 1.21.1)**
- Menú in-game con Shift derecho: rejilla de módulos, buscador, categorías, favoritos y panel de ajustes por módulo.
- 14 módulos: Logo, FPS, CPS, Teclas, Ping, Coordenadas, Reloj, Velocidad, Dirección, Memoria, Servidor, Armadura, Zoom y Fullbright.
- Color por módulo, chroma, escala, fondo, sombra; editor para mover el HUD con el ratón.
- Tema: color de acento con selector completo; animaciones, bienvenida y efectos en el menú principal.
- Lista de mods instalados.
