@echo off
setlocal
chcp 65001 >nul 2>&1
cd /d "%~dp0"
set "TOOLS=%~dp0.build-tools"
if not exist "%TOOLS%" mkdir "%TOOLS%"

echo === Ametra: compilando el mod (la primera vez tarda varios minutos) ===

if not exist "%TOOLS%\jdk\bin\javac.exe" (
  echo [1/3] Descargando JDK 21...
  powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://api.adoptium.net/v3/binary/latest/21/ga/windows/x64/jdk/hotspot/normal/eclipse' -OutFile '%TOOLS%\jdk.zip'; Expand-Archive '%TOOLS%\jdk.zip' '%TOOLS%\jdk-tmp' -Force"
  if exist "%TOOLS%\jdk" rmdir /s /q "%TOOLS%\jdk"
  for /d %%D in ("%TOOLS%\jdk-tmp\*") do move "%%D" "%TOOLS%\jdk" >nul
  rmdir /s /q "%TOOLS%\jdk-tmp" 2>nul
  del "%TOOLS%\jdk.zip" 2>nul
)
if not exist "%TOOLS%\jdk\bin\javac.exe" ( echo ERROR: no se pudo instalar el JDK. & pause & exit /b 1 )

if not exist "%TOOLS%\gradle\bin\gradle.bat" (
  echo [2/3] Descargando Gradle...
  powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.12-bin.zip' -OutFile '%TOOLS%\gradle.zip'; Expand-Archive '%TOOLS%\gradle.zip' '%TOOLS%\gradle-tmp' -Force"
  if exist "%TOOLS%\gradle" rmdir /s /q "%TOOLS%\gradle"
  for /d %%D in ("%TOOLS%\gradle-tmp\*") do move "%%D" "%TOOLS%\gradle" >nul
  rmdir /s /q "%TOOLS%\gradle-tmp" 2>nul
  del "%TOOLS%\gradle.zip" 2>nul
)
if not exist "%TOOLS%\gradle\bin\gradle.bat" ( echo ERROR: no se pudo instalar Gradle. & pause & exit /b 1 )

set "JAVA_HOME=%TOOLS%\jdk"
set "PATH=%JAVA_HOME%\bin;%TOOLS%\gradle\bin;%PATH%"

echo [3/3] Compilando...
cd ametra-mod
call gradle build --no-daemon
if errorlevel 1 (
  echo.
  echo ERROR al compilar. Copia el texto rojo de arriba y mandaselo a Claude.
  pause
  exit /b 1
)

if not exist "..\mod" mkdir "..\mod"
for %%F in (build\libs\ametra-client-*.jar) do (
  echo %%F | findstr /i "sources" >nul || copy /y "%%F" "..\mod\ametra-client.jar" >nul
)
if exist "..\mod\ametra-client.jar" (
  echo.
  echo LISTO: mod\ametra-client.jar creado. Abre el launcher, juega 1.21.1 y pulsa Shift derecho.
) else (
  echo ERROR: no se encontro el .jar compilado.
)
pause
