const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('ametra', {
  minimize: () => ipcRenderer.send('win:min'),
  close: () => ipcRenderer.send('win:close'),
  play: (opts) => ipcRenderer.invoke('play', opts),
  versions: () => ipcRenderer.invoke('versions:list'),
  clientMods: (id) => ipcRenderer.invoke('client:mods', id),
  toggleMod: (o) => ipcRenderer.invoke('client:toggle', o),
  saveConfig: (id, config) => ipcRenderer.invoke('client:config', { id, config }),
  modStatus: () => ipcRenderer.invoke('mod:status'),
  readConfig: (id) => ipcRenderer.invoke('client:readConfig', id),
  optPlan: (version) => ipcRenderer.invoke('opt:plan', version),
  optInstall: (o) => ipcRenderer.invoke('opt:install', o),
  loginMs: (silent) => ipcRenderer.invoke('login:ms', !!silent),
  openSkin: () => ipcRenderer.send('skin:open'),
  addMods: (id) => ipcRenderer.invoke('mods:add', id),
  openMods: (id) => ipcRenderer.invoke('mods:open', id),
  on: (channel, fn) => ipcRenderer.on(channel, (_e, data) => fn(data))
});
