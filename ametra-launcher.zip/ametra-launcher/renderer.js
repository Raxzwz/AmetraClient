const $ = (id) => document.getElementById(id);

// ---------- Estado ----------
const DEF = { name: '', ram: 4, java: '', last: 'default', mode: 'offline', fabric: false,
  profile: 'pvp', ametra: true, optimize: true, modernJava: true, accent: '#8fd6a8', hud: { logo: true, cps: true, keys: true, fps: true, ping: false, clock: false, coords: false, speed: false, dir: false, ram: false, server: false, armor: false, zoom: true, fullbright: false },
  profiles: [
    { id: 'pvp', name: 'PvP / FPS', fixed: true, mods: ['sodium', 'lithium', 'ok-zoomer'], ram: 4, cape: 'none', hud: { cps: true, keys: true, fps: true, coords: false } },
    { id: 'shaders', name: 'Shaders', fixed: true, mods: ['sodium', 'iris', 'lithium'], ram: 6, cape: 'none', hud: { cps: false, keys: false, fps: true, coords: false } },
    { id: 'limpio', name: 'Limpio', fixed: true, mods: [], ram: 4, cape: 'none', hud: { cps: false, keys: false, fps: false, coords: false } }
  ],
  instances: [{ id: 'default', name: 'Minecraft', version: '1.21.1', tag: 'Vanilla' }] };
let S;
try { S = { ...DEF, ...JSON.parse(localStorage.getItem('ametra') || localStorage.getItem('hovy') || '{}') }; } catch { S = { ...DEF }; }
if (!S.instances.length) S.instances = DEF.instances;
const save = () => localStorage.setItem('ametra', JSON.stringify(S));
const current = () => S.instances.find((i) => i.id === S.last) || S.instances[0];
let startedAt = 0, runningId = null;

// ---------- Ventana ----------
$('min').onclick = () => ametra.minimize();
$('close').onclick = () => ametra.close();

// ---------- Navegación ----------
document.querySelectorAll('.dock button').forEach((b) => {
  b.onclick = () => {
    document.querySelectorAll('.dock button').forEach((x) => x.classList.toggle('on', x === b));
    document.querySelectorAll('.page').forEach((p) => p.classList.toggle('active', p.id === 'page-' + b.dataset.page));
  };
});

// ---------- Avatar de píxeles (según el nombre) ----------
function drawAvatar() {
  const c = $('avatar').getContext('2d');
  if (skinImg && S.mode === 'ms') {
    c.clearRect(0, 0, 8, 8);
    c.drawImage(skinImg, 8, 8, 8, 8, 0, 0, 8, 8);
    c.drawImage(skinImg, 40, 8, 8, 8, 0, 0, 8, 8);
    return;
  }
  const n = S.name || 'Steve';
  let h = 0; for (const ch of n) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  const skins = ['#e8b98f', '#c98c62', '#f0cfae', '#8d5a3b'];
  const hairs = ['#3b2415', '#1b1b1b', '#7a4a21', '#b8862e'];
  const skin = skins[h % 4], hair = hairs[(h >> 3) % 4];
  c.clearRect(0, 0, 8, 8);
  c.fillStyle = skin; c.fillRect(0, 0, 8, 8);
  c.fillStyle = hair; c.fillRect(0, 0, 8, 2); c.fillRect(0, 2, 1, 1); c.fillRect(7, 2, 1, 1);
  c.fillStyle = '#fff'; c.fillRect(1, 4, 2, 1); c.fillRect(5, 4, 2, 1);
  c.fillStyle = '#3a2b8f'; c.fillRect(2, 4, 1, 1); c.fillRect(5, 4, 1, 1);
  c.fillStyle = '#8a4a3a'; c.fillRect(3, 6, 2, 1);
}

// ---------- Tiempo y estadísticas ----------
function fmtTime(ms) {
  const m = Math.floor(ms / 60000);
  if (m < 1) return '0 min';
  const h = Math.floor(m / 60);
  return h ? `${h} h ${m % 60} min` : `${m} min`;
}
function ago(t) {
  if (!t) return 'Nunca';
  const d = Math.floor((Date.now() - t) / 86400000);
  return d < 1 ? 'Hoy' : d === 1 ? 'Ayer' : `Hace ${d} días`;
}
function renderStats() {
  $('stTime').textContent = fmtTime(S.instances.reduce((a, i) => a + (i.time || 0), 0));
  $('stInst').textContent = S.instances.length;
  $('stLast').textContent = ago(Math.max(0, ...S.instances.map((i) => i.last || 0)));
}

// ---------- Inicio ----------
const COLORS = ['#8fd6a8', '#f0b27a', '#85c1e9', '#d7a8f0', '#f1948a'];

function greet() {
  const h = new Date().getHours();
  const hi = h < 12 ? 'Buenos días' : h < 19 ? 'Buenas tardes' : 'Buenas noches';
  $('greet').textContent = hi + ', ';
  const s = document.createElement('span');
  s.textContent = S.name || 'jugador';
  $('greet').appendChild(s);
}

function render() {
  greet(); drawAvatar();
  const cur = current();
  $('heroName').textContent = cur.name;
  $('heroMeta').textContent = `${S.fabric ? 'Fabric' : cur.tag} · ${cur.version} · ${fmtTime(cur.time || 0)} jugados`;

  const box = $('instances');
  box.textContent = '';
  S.instances.forEach((inst, i) => {
    const el = document.createElement('div');
    el.className = 'inst' + (inst.id === cur.id ? ' sel' : '');
    const ico = document.createElement('div');
    ico.className = 'ico';
    ico.textContent = inst.name[0].toUpperCase();
    ico.style.background = COLORS[i % COLORS.length];
    el.style.setProperty('--ac', COLORS[i % COLORS.length]);
    const info = document.createElement('div');
    info.className = 'info';
    const b = document.createElement('b'); b.textContent = inst.name;
    const m = document.createElement('span'); m.className = 'meta'; m.textContent = `${inst.tag} · ${inst.version} · ${fmtTime(inst.time || 0)}`;
    info.append(b, m);
    const go = document.createElement('button');
    go.className = 'go'; go.textContent = '→'; go.setAttribute('aria-label', 'Seleccionar');
    el.append(ico, info, go);
    if (S.instances.length > 1) {
      const del = document.createElement('button');
      del.className = 'del'; del.textContent = '×'; del.setAttribute('aria-label', 'Eliminar');
      del.onclick = (e) => { e.stopPropagation(); S.instances = S.instances.filter((x) => x.id !== inst.id); save(); render(); };
      el.append(del);
    }
    el.onclick = () => { S.last = inst.id; save(); render(); };
    box.appendChild(el);
  });
  const add = document.createElement('button');
  add.className = 'add'; add.textContent = '+  Añadir instancia';
  add.onclick = () => { $('iName').value = ''; $('dlg').showModal(); $('iName').focus(); };
  box.appendChild(add);
  renderStats();
  renderClient();
}

$('dlgForm').addEventListener('submit', (e) => {
  if (e.submitter && e.submitter.value === 'ok') {
    const name = $('iName').value.trim() || 'Nueva instancia';
    const id = 'i' + Date.now();
    S.instances.push({ id, name, version: $('iVersion').value, tag: 'Vanilla' });
    S.last = id; save(); render();
  }
});

// ---------- Ajustes y perfil ----------
$('ram').value = S.ram; $('ramLabel').textContent = S.ram + ' GB';
$('ram').oninput = () => { S.ram = $('ram').value; $('ramLabel').textContent = S.ram + ' GB'; save(); };
$('java').value = S.java;
$('java').oninput = () => { S.java = $('java').value.trim(); save(); };
$('name').value = S.name;
$('name').oninput = () => { S.name = $('name').value.trim(); save(); greet(); drawAvatar(); };

// ---------- Progreso ----------
const labels = { assets: 'Descargando recursos', classes: 'Descargando librerías', natives: 'Preparando archivos nativos', 'version-jar': 'Descargando Minecraft' };
ametra.on('progress', ({ type, percent }) => {
  $('bar').hidden = false; $('fill').style.width = percent + '%';
  $('status').textContent = `${labels[type] || 'Descargando'}… ${percent}%`;
});
ametra.on('started', () => { $('fill').style.width = '100%'; $('status').textContent = 'Minecraft se está abriendo…'; startedAt = Date.now(); });
ametra.on('warn', (m) => { $('modWarn').textContent = m || ''; });
ametra.modStatus().then((ok) => {
  if (!ok && S.ametra !== false) $('modWarn').textContent = 'Falta mod/ametra-client.jar: sin él NO aparece el menú de Shift derecho. Compila el mod (README → GitHub Actions) y cópialo ahí.';
}).catch(() => {});
let lastHint = '';
ametra.on('hint', (m) => { lastHint = m; });
ametra.on('closed', (code) => {
  if (startedAt && runningId) {
    const i = S.instances.find((x) => x.id === runningId);
    if (i) { i.time = (i.time || 0) + (Date.now() - startedAt); i.last = Date.now(); save(); render(); }
    startedAt = 0;
  }
  $('play').disabled = false; $('play').innerHTML = '▶&nbsp; Jugar'; $('bar').hidden = true;
  $('status').textContent = code === 0 ? '' : (lastHint || `Minecraft se cerró con código ${code}.`);
  lastHint = '';
});

// ---------- Versiones ----------
const FAMOUS = ['1.21.4', '1.21.1', '1.20.4', '1.20.1', '1.19.4', '1.18.2', '1.16.5', '1.12.2', '1.8.9', '1.7.10'];
async function loadVersions() {
  let all = [];
  try { all = await ametra.versions(); } catch { /* sin internet: solo las famosas */ }
  const sel = $('iVersion');
  sel.textContent = '';
  const group = (label, list) => {
    const g = document.createElement('optgroup');
    g.label = label;
    list.forEach((v) => { const o = document.createElement('option'); o.textContent = v; g.appendChild(o); });
    sel.appendChild(g);
  };
  group('Más famosas', FAMOUS);
  const rest = all.filter((v) => !FAMOUS.includes(v));
  if (rest.length) group('Todas las versiones', rest);
}
loadVersions();

let skinImg = null;

// ---------- Cuenta ----------
let msOk = false;
function paintAccount() {
  const ms = S.mode === 'ms';
  $('modeOff').classList.toggle('on', !ms);
  $('modeMs').classList.toggle('on', ms);
  $('name').disabled = ms;
  $('acctInfo').textContent = ms
    ? (msOk ? 'Sesión de Microsoft iniciada.' : 'Pulsa "Microsoft (premium)" para iniciar sesión.')
    : 'Modo sin conexión: sirve para un jugador y servidores sin verificación.';
}
$('modeOff').onclick = () => { S.mode = 'offline'; save(); paintAccount(); refreshSkin(); };
$('modeMs').onclick = async () => {
  S.mode = 'ms'; paintAccount(); refreshSkin();
  $('acctInfo').textContent = 'Abriendo inicio de sesión…';
  try {
    const r = await ametra.loginMs();
    applyLogin(r);
  } catch (e) { msOk = false; $('acctInfo').textContent = 'No se pudo iniciar sesión: ' + e.message; return; }
  paintAccount();
};
$('skin').onclick = () => ametra.openSkin();

// ---------- Fabric y mods ----------
$('fabric').checked = !!S.fabric;
$('ametra').checked = S.ametra !== false;
$('optimize').checked = S.optimize !== false;
$('modernJava').checked = S.modernJava !== false;
$('optimize').onchange = () => { S.optimize = $('optimize').checked; save(); renderOpt(); };
$('modernJava').onchange = () => { S.modernJava = $('modernJava').checked; save(); renderOpt(); };
$('ametra').onchange = () => { S.ametra = $('ametra').checked; save(); };
$('accent').onchange = () => {
  S.accent = $('accent').value; $('accentHex').textContent = S.accent.toUpperCase();
  save(); writeConfig(['accent']);
};
$('fabric').onchange = () => { S.fabric = $('fabric').checked; save(); };
$('addMods').onclick = async () => {
  const n = await ametra.addMods(current().id);
  $('modsInfo').textContent = n ? `${n} mod(s) añadido(s) a "${current().name}".` : 'No se añadió ningún mod.';
};
$('openMods').onclick = () => ametra.openMods(current().id);

// ---------- Jugar ----------
function resetPlay() { $('play').disabled = false; $('play').innerHTML = '▶&nbsp; Jugar'; $('bar').hidden = true; }
ametra.on('info', (m) => { $('status').textContent = m; });
ametra.on('error', (m) => { resetPlay(); $('status').textContent = m; });

$('play').onclick = async () => {
  const goProfile = () => { document.querySelector('[data-page=profile]').click(); };
  if (S.mode === 'ms' && !msOk) {
    $('status').textContent = 'Iniciando sesión con Microsoft…';
    try {
      const r = await ametra.loginMs(false);
      applyLogin(r);
    } catch (e) { $('status').textContent = 'No se pudo iniciar sesión: ' + e.message; goProfile(); return; }
  }
  if (S.mode === 'offline' && !/^\w{3,16}$/.test(S.name)) { goProfile(); $('name').focus(); return; }
  const cur = current();
  runningId = cur.id; $('play').disabled = true; $('play').textContent = 'Iniciando…'; $('status').textContent = 'Preparando…';
  ametra.play({ id: cur.id, name: S.name, version: cur.version, ram: S.ram, java: S.java, mode: S.mode, fabric: S.fabric, ametra: S.ametra !== false, optimize: S.optimize !== false, modernJava: S.modernJava !== false });
};

// ---------- Portada animada ----------
const STARS = Array.from({ length: 70 }, () => ({ x: Math.random(), y: Math.random(), z: Math.random() < 0.2 ? 3 : 2, p: Math.random() * 6 }));
const heroEl = $('hero'), heroC = $('heroBg'), hg = heroC.getContext('2d');
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
let hx = 0, hxT = 0;
heroEl.addEventListener('mousemove', (e) => { const b = heroEl.getBoundingClientRect(); hxT = (e.clientX - b.left) / b.width - 0.5; });
heroEl.addEventListener('mouseleave', () => { hxT = 0; });
$('heroMods').onclick = () => ametra.openMods(current().id);

function heroFrame(t) {
  const w = heroEl.clientWidth, h = heroEl.clientHeight;
  if (w && h) {
    if (heroC.width !== w || heroC.height !== h) { heroC.width = w; heroC.height = h; }
    if (!reduce) hx += (hxT - hx) * 0.06;
    const time = reduce ? 0 : t;
    const sky = hg.createLinearGradient(0, 0, 0, h);
    sky.addColorStop(0, '#0a0716'); sky.addColorStop(1, '#241440');
    hg.fillStyle = sky; hg.fillRect(0, 0, w, h);
    hg.fillStyle = '#fff';
    for (const s of STARS) { hg.globalAlpha = 0.25 + 0.75 * Math.abs(Math.sin(time / 900 + s.p)); hg.fillRect(s.x * w, s.y * h * 0.65, s.z, s.z); }
    hg.globalAlpha = 1;
    hg.fillStyle = '#ece7ff'; hg.fillRect(w * 0.8, h * 0.14, 28, 28);
    hg.fillStyle = '#d3c9f6'; hg.fillRect(w * 0.8 + 6, h * 0.14 + 6, 9, 9);
    [[0.52, '#150e2b', 0.15, 40], [0.68, '#0d0919', 0.4, 32], [0.82, '#060409', 0.8, 26]].forEach(([base, col, par, bw], li) => {
      hg.fillStyle = col;
      const off = hx * par * 70, shift = Math.floor(off / bw);
      for (let i = -2; i < w / bw + 2; i++) {
        const idx = i - shift;
        const n = Math.sin(idx * 0.7 + li * 3) + Math.sin(idx * 0.23 + li) * 1.5;
        const top = h * base - Math.round(n * 2) * 8;
        hg.fillRect(i * bw + (off % bw), top, bw + 1, h - top);
      }
    });
  }
  requestAnimationFrame(heroFrame);
}
requestAnimationFrame(heroFrame);

document.querySelectorAll('.dock button').forEach((b) => { b.dataset.tip = b.getAttribute('aria-label'); });

// ---------- Cliente: módulos y capas ----------
const MODS = [
  { slug: 'sodium', name: 'Sodium', desc: 'Más FPS con un motor de render optimizado.' },
  { slug: 'lithium', name: 'Lithium', desc: 'Optimiza la lógica del juego.' },
  { slug: 'iris', name: 'Iris Shaders', desc: 'Shaders compatibles con Sodium.' },
  { slug: 'ok-zoomer', name: 'Ok Zoomer', desc: 'Zoom ajustable, como el de OptiFine.' },
  { slug: 'modmenu', name: 'Mod Menu', desc: 'Lista y configura tus mods dentro del juego.' },
  { slug: 'appleskin', name: 'AppleSkin', desc: 'Muestra hambre y saturación.' }
];
const CAPES = [
  { id: 'none', name: 'Ninguna' }, { id: 'amatista', name: 'Amatista', c: ['#6f48c9', '#c8a8ff'] },
  { id: 'esmeralda', name: 'Esmeralda', c: ['#1f7a4d', '#8fd6a8'] }, { id: 'rubi', name: 'Rubí', c: ['#9b1c31', '#f1948a'] },
  { id: 'oro', name: 'Oro', c: ['#b8862e', '#ffd27a'] }, { id: 'noche', name: 'Noche', c: ['#14161d', '#85c1e9'] }
];
function drawCape(cv, cape, i) {
  const g = cv.getContext('2d');
  if (!cape.c) { g.strokeStyle = '#555'; g.strokeRect(1.5, 1.5, 7, 13); return; }
  g.fillStyle = cape.c[0]; g.fillRect(0, 0, 10, 16);
  g.fillStyle = cape.c[1];
  if (i % 3 === 1) { g.fillRect(4, 0, 2, 16); }
  else if (i % 3 === 2) { g.fillRect(0, 0, 10, 1); g.fillRect(0, 15, 10, 1); g.fillRect(0, 0, 1, 16); g.fillRect(9, 0, 1, 16); }
  else { for (let y = 2; y < 16; y += 4) g.fillRect(0, y, 10, 1); }
}
let modBusy = false;
async function renderClient() {
  const cur = current();
  $('clInst').textContent = `Instancia: ${cur.name} · ${cur.version}. Los módulos se instalan en esta instancia.`;
  let on = [];
  try { on = await ametra.clientMods(cur.id); } catch { /* sin datos */ }
  try {
    const cfg = await ametra.readConfig(cur.id);
    if (cfg && cfg.hud) S.hud = { ...S.hud, ...cfg.hud };
    if (cfg && /^#[0-9a-f]{6}$/i.test(cfg.accent || '')) S.accent = cfg.accent.toLowerCase();
  } catch { /* sin config todavía */ }
  $('accent').value = S.accent || '#8fd6a8';
  $('accentHex').textContent = ($('accent').value || '').toUpperCase();
  const list = $('modList');
  list.textContent = '';
  MODS.forEach((m) => {
    const row = document.createElement('div'); row.className = 'mod';
    const info = document.createElement('div'); info.className = 'info';
    const b = document.createElement('b'); b.textContent = m.name;
    const d = document.createElement('span'); d.className = 'meta'; d.textContent = m.desc;
    info.append(b, d);
    const sw = document.createElement('button');
    sw.className = 'sw' + (on.includes(m.slug) ? ' on' : '');
    sw.setAttribute('aria-label', m.name);
    sw.onclick = async () => {
      if (modBusy) return;
      modBusy = true; sw.disabled = true;
      const turnOn = !sw.classList.contains('on');
      $('clMsg').textContent = turnOn ? `Instalando ${m.name}…` : `Quitando ${m.name}…`;
      try {
        await ametra.toggleMod({ id: cur.id, version: cur.version, slug: m.slug, on: turnOn });
        sw.classList.toggle('on', turnOn);
        if (turnOn) { S.fabric = true; $('fabric').checked = true; save(); }
        $('clMsg').textContent = turnOn ? `${m.name} listo. Se activa al jugar con Fabric.` : `${m.name} quitado.`;
      } catch (e) { $('clMsg').textContent = `No se pudo: ${e.message}`; }
      modBusy = false; sw.disabled = false;
    };
    row.append(info, sw);
    list.appendChild(row);
  });
  const capes = $('capeList');
  capes.textContent = '';
  CAPES.forEach((c, i) => {
    const el = document.createElement('button');
    el.className = 'cape' + ((S.cape || 'none') === c.id ? ' sel' : '');
    const cv = document.createElement('canvas'); cv.width = 10; cv.height = 16;
    drawCape(cv, c, i);
    el.append(cv, document.createTextNode(c.name));
    el.onclick = () => { S.cape = c.id; save(); writeConfig(['cape']); renderClient(); };
    capes.appendChild(el);
  });
  renderProfiles();
  renderHud();
  renderOpt();
}

// ---------- Perfiles y HUD ----------
const HUD = [['logo', 'Logo'], ['fps', 'FPS'], ['cps', 'CPS (clics)'], ['keys', 'Teclas'], ['ping', 'Ping'], ['coords', 'Coordenadas'], ['clock', 'Reloj'],
  ['speed', 'Velocidad'], ['dir', 'Dirección'], ['ram', 'Memoria'], ['server', 'Servidor'], ['armor', 'Armadura'], ['zoom', 'Zoom'], ['fullbright', 'Fullbright']];
// Solo se escriben las claves indicadas: lo demás (posiciones, colores del juego) lo guarda el mod.
function writeConfig(keys = ['profile', 'cape', 'hud']) {
  const p = S.profiles.find((x) => x.id === S.profile);
  const all = { profile: p ? p.name : null, cape: S.cape || 'none', hud: S.hud, accent: S.accent || '#8fd6a8' };
  const cfg = {};
  keys.forEach((k) => { cfg[k] = all[k]; });
  ametra.saveConfig(current().id, cfg);
}
function renderHud() {
  const box = $('hudList');
  box.textContent = '';
  HUD.forEach(([k, label]) => {
    const b = document.createElement('button');
    b.className = 'chip' + (S.hud[k] ? ' on' : '');
    b.textContent = label;
    b.onclick = () => { S.hud[k] = !S.hud[k]; save(); writeConfig(['hud']); renderHud(); };
    box.appendChild(b);
  });
}
function renderProfiles() {
  const box = $('profList');
  box.textContent = '';
  S.profiles.forEach((p) => {
    const el = document.createElement('button');
    el.className = 'prof' + (p.id === S.profile ? ' sel' : '');
    const b = document.createElement('b'); b.textContent = p.name;
    const m = document.createElement('span'); m.className = 'meta'; m.textContent = `${p.mods.length} módulos · ${p.ram} GB`;
    el.append(b, m);
    if (!p.fixed) {
      const x = document.createElement('span'); x.className = 'x'; x.textContent = '×';
      x.onclick = (e) => { e.stopPropagation(); S.profiles = S.profiles.filter((q) => q.id !== p.id); if (S.profile === p.id) S.profile = null; save(); renderProfiles(); };
      el.append(x);
    }
    el.onclick = () => applyProfile(p);
    box.appendChild(el);
  });
  const add = document.createElement('button');
  add.className = 'prof new'; add.textContent = '+ Guardar actual como perfil';
  add.onclick = () => { $('pName').value = ''; $('dlgProf').showModal(); $('pName').focus(); };
  box.appendChild(add);
}
async function applyProfile(p) {
  if (modBusy) return;
  modBusy = true;
  const cur = current();
  try {
    const have = await ametra.clientMods(cur.id);
    for (const m of MODS) {
      const want = p.mods.includes(m.slug);
      if (want !== have.includes(m.slug)) {
        $('clMsg').textContent = `${want ? 'Instalando' : 'Quitando'} ${m.name}…`;
        await ametra.toggleMod({ id: cur.id, version: cur.version, slug: m.slug, on: want });
      }
    }
    S.ram = p.ram; S.cape = p.cape || 'none'; S.hud = { ...p.hud }; S.profile = p.id; S.fabric = p.mods.length > 0;
    $('ram').value = S.ram; $('ramLabel').textContent = S.ram + ' GB'; $('fabric').checked = S.fabric;
    save(); writeConfig(['profile', 'cape', 'hud']);
    $('clMsg').textContent = `Perfil "${p.name}" aplicado a ${cur.name}.`;
  } catch (e) { $('clMsg').textContent = `No se pudo aplicar: ${e.message}`; }
  modBusy = false;
  renderClient();
}
$('dlgProfForm').addEventListener('submit', async (e) => {
  if (!e.submitter || e.submitter.value !== 'ok') return;
  const have = await ametra.clientMods(current().id);
  const p = { id: 'p' + Date.now(), name: $('pName').value.trim() || 'Mi perfil', mods: have.filter((s) => MODS.some((m) => m.slug === s)), ram: Number(S.ram), cape: S.cape || 'none', hud: { ...S.hud } };
  S.profiles.push(p); S.profile = p.id; save(); writeConfig(['profile']); renderProfiles();
});

// ---------- Skin en 3D ----------
const SK = 7;
const stage = $('skin3d'), model = $('model');
let skinSrc = '', skinH = 64, yaw = -25, pitch = -10, dragging = false, lastX = 0, lastY = 0;

function makeDefaultSkin() {
  const c = document.createElement('canvas'); c.width = c.height = 64;
  const g = c.getContext('2d');
  let h = 0; for (const ch of (S.name || 'Steve')) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  const skin = ['#e8b98f', '#c98c62', '#f0cfae', '#8d5a3b'][h % 4], hair = ['#3b2415', '#1b1b1b', '#7a4a21', '#b8862e'][(h >> 3) % 4];
  const f = (col, x, y, w, hh) => { g.fillStyle = col; g.fillRect(x, y, w, hh); };
  f(skin, 0, 0, 32, 16); f(hair, 8, 0, 8, 8); f(hair, 0, 8, 32, 2); f(hair, 24, 8, 8, 8);
  f('#fff', 9, 12, 2, 1); f('#fff', 13, 12, 2, 1); f('#3a2b8f', 10, 12, 1, 1); f('#3a2b8f', 13, 12, 1, 1); f('#8a4a3a', 11, 14, 2, 1);
  f('#3aa6b5', 16, 16, 24, 16);
  [[40, 16], [32, 48]].forEach(([x, y]) => { f(skin, x, y, 16, 16); f('#3aa6b5', x, y + 4, 16, 4); });
  [[0, 16], [16, 48]].forEach(([x, y]) => { f('#3b44a5', x, y, 16, 16); f('#6b6b6b', x, y + 14, 16, 2); });
  return c.toDataURL();
}

function uv(ox, oy, w, h, d) {
  return { top: [ox + d, oy], bottom: [ox + d + w, oy], right: [ox, oy + d], front: [ox + d, oy + d], left: [ox + d + w, oy + d], back: [ox + d + w + d, oy + d] };
}
function face(part, fw, fh, u, v, tf) {
  const f = document.createElement('div');
  f.className = 'face';
  f.style.width = fw * SK + 'px'; f.style.height = fh * SK + 'px';
  f.style.left = -fw * SK / 2 + 'px'; f.style.top = -fh * SK / 2 + 'px';
  f.style.backgroundImage = `url(${skinSrc})`;
  f.style.backgroundSize = `${64 * SK}px ${skinH * SK}px`;
  f.style.backgroundPosition = `${-u * SK}px ${-v * SK}px`;
  f.style.transform = tf;
  part.appendChild(f);
}
function cube(x, y, w, h, d, o) {
  const p = document.createElement('div');
  p.className = 'part';
  p.style.transform = `translate3d(${x * SK}px, ${y * SK}px, 0)`;
  const W = w * SK, H = h * SK, D = d * SK;
  face(p, w, h, ...o.front, `translateZ(${D / 2}px)`);
  face(p, w, h, ...o.back, `rotateY(180deg) translateZ(${D / 2}px)`);
  face(p, d, h, ...o.right, `rotateY(-90deg) translateZ(${W / 2}px)`);
  face(p, d, h, ...o.left, `rotateY(90deg) translateZ(${W / 2}px)`);
  face(p, w, d, ...o.top, `rotateX(90deg) translateZ(${H / 2}px)`);
  face(p, w, d, ...o.bottom, `rotateX(-90deg) translateZ(${H / 2}px)`);
  model.appendChild(p);
}
function buildModel(slim) {
  model.textContent = '';
  const aw = slim ? 3 : 4, old = skinH < 64;
  cube(0, -12, 8, 8, 8, uv(0, 0, 8, 8, 8));
  cube(0, -2, 8, 12, 4, uv(16, 16, 8, 12, 4));
  cube(-(4 + aw / 2), -2, aw, 12, 4, uv(40, 16, aw, 12, 4));
  cube(4 + aw / 2, -2, aw, 12, 4, old ? uv(40, 16, aw, 12, 4) : uv(32, 48, aw, 12, 4));
  cube(-2, 10, 4, 12, 4, uv(0, 16, 4, 12, 4));
  cube(2, 10, 4, 12, 4, old ? uv(0, 16, 4, 12, 4) : uv(16, 48, 4, 12, 4));
}
function setSkin(src, slim, real, label) {
  const img = new Image();
  img.onload = () => {
    skinSrc = src; skinH = img.naturalHeight; skinImg = real ? img : null;
    buildModel(slim); drawAvatar();
    $('skinName').textContent = label;
  };
  img.src = src;
}
function refreshSkin() {
  if (S.mode === 'ms' && S.skin) setSkin(S.skin, !!S.slim, true, S.name);
  else if (S.mode === 'ms') setSkin(makeDefaultSkin(), false, false, 'Sin skin personalizada');
  else setSkin(makeDefaultSkin(), false, false, 'Skin predeterminada (sin conexión)');
}
function applyLogin(a) {
  msOk = true; S.name = a.name; S.skin = a.skin || null; S.slim = !!a.slim;
  $('name').value = a.name; save(); paintAccount(); refreshSkin(); render();
}

stage.addEventListener('pointerdown', (e) => { dragging = true; lastX = e.clientX; lastY = e.clientY; stage.setPointerCapture(e.pointerId); });
stage.addEventListener('pointermove', (e) => {
  if (!dragging) return;
  yaw += (e.clientX - lastX) * 0.8; pitch = Math.max(-40, Math.min(25, pitch - (e.clientY - lastY) * 0.5));
  lastX = e.clientX; lastY = e.clientY;
});
stage.addEventListener('pointerup', () => { dragging = false; });
(function spin() {
  if (stage.clientWidth) {
    if (!dragging && !matchMedia('(prefers-reduced-motion: reduce)').matches) yaw += 0.4;
    model.style.transform = `rotateX(${pitch}deg) rotateY(${yaw}deg)`;
  }
  requestAnimationFrame(spin);
})();
$('name').addEventListener('input', () => { if (S.mode === 'offline') refreshSkin(); });

refreshSkin();
if (S.mode === 'ms') {
  ametra.loginMs(true).then(applyLogin).catch(() => {});
}

paintAccount();
render();


// ---------- Pack de optimización (tarjeta de la pestaña Cliente) ----------
const ERA = { fabric: 'Fabric', 'legacy-fabric': 'Legacy Fabric' };
let optSeq = 0;
async function renderOpt() {
  const cur = current(), seq = ++optSeq;
  const on = S.optimize !== false, modern = S.modernJava !== false;
  $('optSummary').textContent = 'Calculando…';
  $('optMods').textContent = '';
  $('optNow').disabled = !on;
  let p;
  try { p = await ametra.optPlan(cur.version); } catch { $('optSummary').textContent = 'Sin internet: no se pudo calcular el plan de esta versión.'; return; }
  if (seq !== optSeq) return; // el usuario cambió de instancia mientras tanto
  const javaTxt = !modern ? `Java ${p.java.required} (el que pide Mojang)` : p.java.why;
  const loader = p.loader ? ERA[p.loader] : 'sin loader (versión muy antigua)';
  $('optSummary').textContent = on
    ? `${cur.name} · ${cur.version} · ${loader} · ${javaTxt}${p.video ? ' · ajustes de vídeo ligeros' : ''}`
    : 'Desactivado: esta instancia se juega sin el pack (los mods del pack ya instalados se quitan al jugar).';
  const ul = $('optMods');
  if (on) {
    p.mods.forEach((m) => { const li = document.createElement('li'); li.textContent = m.name; li.title = m.why; ul.appendChild(li); });
    if (p.discover) { const li = document.createElement('li'); li.className = 'more'; li.textContent = '+ mods de rendimiento de Legacy Fabric (se buscan en Modrinth)'; ul.appendChild(li); }
    if (!p.mods.length && !p.discover) { const li = document.createElement('li'); li.textContent = 'Solo Java + flags de la JVM'; ul.appendChild(li); }
  }
}
$('optNow').onclick = async () => {
  const cur = current();
  $('optNow').disabled = true; $('optMsg').textContent = 'Instalando el pack…';
  try {
    const r = await ametra.optInstall({ id: cur.id, version: cur.version });
    $('optMsg').textContent = r.loader
      ? `Listo: ${r.installed.length} mod(s) instalados${r.skipped.length ? `; sin versión para ${cur.version}: ${r.skipped.join(', ')}` : ''}.`
      : 'Esta versión no tiene loader: solo se aplican Java y flags al jugar.';
  } catch (e) { $('optMsg').textContent = `No se pudo: ${e.message}`; }
  $('optNow').disabled = S.optimize === false;
};
